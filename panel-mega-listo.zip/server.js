const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Database functions
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);

function readDB(file) {
  const filepath = path.join(DATA_DIR, file);
  if (!fs.existsSync(filepath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filepath, 'utf8'));
  } catch (e) {
    return null;
  }
}

function writeDB(file, data) {
  fs.writeFileSync(path.join(DATA_DIR, file), JSON.stringify(data, null, 2));
}

// Force seed the primary admin user if missing
let initUsers = readDB('users.json');
if (!initUsers || !Array.isArray(initUsers)) initUsers = [];

const angelExists = initUsers.find(u => u.username.toLowerCase() === 'angel');
if (!angelExists) {
  // Remove the old default 'admin' if it exists to keep it clean
  initUsers = initUsers.filter(u => u.username !== 'admin');
  initUsers.push({
    id: Date.now(),
    username: 'Angel',
    password: 'angel067L',
    role: 'admin',
    credits: 0
  });
  writeDB('users.json', initUsers);
}

const initSettings = readDB('settings.json');
if (!initSettings || !initSettings.apiaccesskey || initSettings.apiaccesskey === '' || initSettings.masterUsername !== 'angeljuares067@gmail.com') {
  writeDB('settings.json', {
    masterUsername: 'angeljuares067@gmail.com',
    apiaccesskey: 'pk60-qXSs-xXsF-qZPa',
    endpoint: 'https://latamgsm.com/dhru/',
    resellerMarkup: 0,
    clientMarkup: 0
  });
}

// In-memory token store
const sessions = {};

// Auth Middleware
function requireAuth(req, res, next) {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token || !sessions[token]) {
    return res.status(401).json({ error: 'Unauthorized. Please login again.' });
  }
  req.user = sessions[token]; // attach user object to request
  next();
}

function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden. Admin access required.' });
  }
  next();
}

// Login Endpoint
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const users = readDB('users.json') || [];
  const user = users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  
  // Generate a simple secure token
  const token = require('crypto').randomBytes(32).toString('hex');
  sessions[token] = user;
  
  res.json({ token, role: user.role, username: user.username, credits: user.credits });
});

// Get My Account Info (Balance)
app.get('/api/me', requireAuth, (req, res) => {
  const users = readDB('users.json') || [];
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  // Update session
  sessions[req.headers['authorization'].split(' ')[1]] = user;
  res.json({ username: user.username, role: user.role, credits: user.credits });
});

// API proxy endpoint for Products
app.get('/api/products', requireAuth, async (req, res) => {
  const settings = readDB('settings.json');
  if (!settings) return res.status(500).json({ error: 'Server misconfigured' });
  
  const { apiaccesskey, masterUsername, endpoint, resellerMarkup, clientMarkup } = settings;
  const username = masterUsername;

  if (!username || !apiaccesskey) {
    return res.status(400).json({ error: 'Username and apiaccesskey are missing in settings.' });
  }

  // Base Dhru Fusion url
  let baseUrl = endpoint || 'https://latamgsm.com/dhru/';
  
  // Normalize the URL to include api path
  if (!baseUrl.endsWith('/')) {
    baseUrl += '/';
  }
  
  // Standard Dhru endpoint is api/index.php. Let's make sure we direct correctly.
  let targetUrl = baseUrl;
  if (!targetUrl.includes('/api/')) {
    targetUrl += 'api/index.php';
  } else if (targetUrl.endsWith('/api/')) {
    targetUrl += 'index.php';
  }

  try {
    const paramsImei = new URLSearchParams();
    paramsImei.append('username', username);
    paramsImei.append('apiaccesskey', apiaccesskey);
    paramsImei.append('action', 'imeiservicelist');
    paramsImei.append('requestformat', 'JSON');

    const paramsServer = new URLSearchParams();
    paramsServer.append('username', username);
    paramsServer.append('apiaccesskey', apiaccesskey);
    paramsServer.append('action', 'serverservicelist');
    paramsServer.append('requestformat', 'JSON');

    const [resImei, resServer] = await Promise.all([
      axios.post(targetUrl, paramsImei.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Dhru-Fusion-Web-Client/1.0' },
        timeout: 15000
      }).catch(e => ({ data: { ERROR: e.message } })),
      axios.post(targetUrl, paramsServer.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Dhru-Fusion-Web-Client/1.0' },
        timeout: 15000
      }).catch(e => ({ data: { ERROR: e.message } }))
    ]);

    let mergedList = {};
    let hasSuccess = false;

    if (resImei.data && resImei.data.SUCCESS && resImei.data.SUCCESS[0] && resImei.data.SUCCESS[0].LIST) {
      mergedList = { ...resImei.data.SUCCESS[0].LIST };
      // Inject IMEI type flag, respecting the API's SERVICETYPE if provided
      for (const groupKey in mergedList) {
        if (mergedList[groupKey].SERVICES) {
          for (const serviceId in mergedList[groupKey].SERVICES) {
            const apiType = mergedList[groupKey].SERVICES[serviceId].SERVICETYPE;
            mergedList[groupKey].SERVICES[serviceId]._SERVICE_TYPE = apiType ? apiType.toUpperCase() : 'IMEI';
          }
        }
      }
      hasSuccess = true;
    }
    
    if (resServer.data && resServer.data.SUCCESS && resServer.data.SUCCESS[0] && resServer.data.SUCCESS[0].LIST) {
      const serverList = resServer.data.SUCCESS[0].LIST;
      for (const groupKey in serverList) {
        // Inject SERVER type flag
        if (serverList[groupKey].SERVICES) {
          for (const serviceId in serverList[groupKey].SERVICES) {
            serverList[groupKey].SERVICES[serviceId]._SERVICE_TYPE = 'SERVER';
          }
        }
        
        if (mergedList[groupKey]) {
           mergedList[groupKey].SERVICES = { ...mergedList[groupKey].SERVICES, ...serverList[groupKey].SERVICES };
        } else {
           mergedList[groupKey] = serverList[groupKey];
        }
      }
      hasSuccess = true;
    }

    if (hasSuccess) {
      const priceCache = {};
      const customPrices = readDB('custom_prices.json') || {};
      
      // Apply pricing logic before sending to client
      for (const groupKey in mergedList) {
        if (mergedList[groupKey].SERVICES) {
          for (const serviceId in mergedList[groupKey].SERVICES) {
            const service = mergedList[groupKey].SERVICES[serviceId];
            // Convert API USD to MXN directly
            const realCreditUSD = parseFloat(service.CREDIT || '0');
            const realCredit = realCreditUSD * 17.60;
            
            // Store the real cost (in MXN) in the secret server cache
            priceCache[serviceId] = realCredit;
            
            let resellerCost, clientPrice;
            
            // Check if there is a manual price override for this service
            if (customPrices[serviceId]) {
              resellerCost = parseFloat(customPrices[serviceId].resellerPrice);
              clientPrice = parseFloat(customPrices[serviceId].clientPrice);
            } else {
              // Math: Reseller Cost (Real + Reseller Markup, rounded UP to integer)
              resellerCost = Math.ceil(realCredit + resellerMarkup);
              // Math: Client Price (Reseller Cost + Client Markup, rounded UP to integer)
              clientPrice = Math.ceil(resellerCost + clientMarkup);
            }
            
            // Replace the CREDIT field so the frontend sees the Reseller cost as the real cost
            service.CREDIT = resellerCost.toString();
            // Inject the recommended client price
            service._CLIENT_PRICE = clientPrice.toString();
            
            // If the requester is an Admin, they get to see the real cost too
            if (req.user.role === 'admin') {
              service._REAL_COST = realCredit.toFixed(2);
            }
          }
        }
      }
      
      // Save real prices to a local cache to prevent frontend price manipulation during ordering
      writeDB('prices.json', priceCache);

      const finalData = { 
        SUCCESS: [ { LIST: mergedList } ],
        debugInfo: {
          msg: "Merged IMEI and Server lists successfully",
          imeiGroupCount: resImei.data?.SUCCESS?.[0]?.LIST ? Object.keys(resImei.data.SUCCESS[0].LIST).length : 0,
          serverGroupCount: resServer.data?.SUCCESS?.[0]?.LIST ? Object.keys(resServer.data.SUCCESS[0].LIST).length : 0
        }
      };
      return res.json(finalData);
    } else {
      return res.status(500).json({ 
        error: 'No response data received from Dhru API for both catalogs.', 
        details: resImei.data?.ERROR || resServer.data?.ERROR || 'Unknown Error' 
      });
    }
  } catch (error) {
    console.error('API Proxy Error:', error.message);
    let status = 500;
    let message = 'Failed to connect to the Dhru Fusion API.';
    
    if (error.response) {
      status = error.response.status;
      message = `Server returned error: ${error.response.statusText}`;
    } else if (error.request) {
      message = 'No response from the Dhru Fusion server. Please check the URL and ensure the server is online.';
    }

    return res.status(status).json({ error: message, details: error.message });
  }
});

// Get account info proxy endpoint
app.get('/api/account', requireAuth, async (req, res) => {
  const users = readDB('users.json') || [];
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  
  // Base response: local credits
  const localCredit = user.credits || 0;
  
  if (user.role === 'admin') {
    const settings = readDB('settings.json');
    if (!settings) return res.status(500).json({ error: 'Settings missing' });
    const { apiaccesskey, masterUsername, endpoint } = settings;
    
    let targetUrl = endpoint || 'https://latamgsm.com/dhru/';
    if (!targetUrl.endsWith('/')) targetUrl += '/';
    if (!targetUrl.includes('/api/')) targetUrl += 'api/index.php';
    else if (targetUrl.endsWith('/api/')) targetUrl += 'index.php';
    
    try {
      const params = new URLSearchParams();
      params.append('username', masterUsername);
      params.append('apiaccesskey', apiaccesskey);
      params.append('action', 'accountinfo');
      params.append('requestformat', 'JSON');
      
      const response = await axios.post(targetUrl, params.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Dhru-Fusion-Web-Client/1.0' },
        timeout: 10000
      });
      
      const dhruCreditUSD = parseFloat(response.data?.SUCCESS?.[0]?.AccountInfo?.creditraw || 0);
      const dhruCredit = dhruCreditUSD * 17.60;
      
      // Calculate assigned credits
      let assignedCredits = 0;
      users.forEach(u => {
        if (u.role !== 'admin') {
          assignedCredits += parseFloat(u.credits || 0);
        }
      });
      const availableCredits = dhruCredit - assignedCredits;

      return res.json({
        SUCCESS: [{
          CREDIT: dhruCredit.toFixed(2),
          ASSIGNED: assignedCredits.toFixed(2),
          AVAILABLE: availableCredits.toFixed(2),
          IS_ADMIN: true
        }]
      });
    } catch (e) {
      // If Dhru fetch fails, still return local credit but indicate error
      return res.json({
        SUCCESS: [{
          CREDIT: "0"
        }]
      });
    }
  } else {
    // For normal resellers, just return their local virtual credit
    return res.json({
      SUCCESS: [{
        CREDIT: localCredit.toString()
      }]
    });
  }
});

// Place order proxy endpoint
app.post('/api/order', requireAuth, async (req, res) => {
  const { serviceid, imei, custom_fields, serviceType, serviceName } = req.body;
  
  const settings = readDB('settings.json');
  const users = readDB('users.json') || [];
  const prices = readDB('prices.json') || {};
  const history = readDB('history.json') || [];
  
  if (!settings || !serviceid) return res.status(400).json({ error: 'Missing serviceid or server settings.' });
  
  const userIndex = users.findIndex(u => u.id === req.user.id);
  if (userIndex === -1) return res.status(404).json({ error: 'User not found' });
  const user = users[userIndex];

  // 1. Calculate Costs securely using backend cache
  const realCost = prices[serviceid] !== undefined ? prices[serviceid] : null;
  if (realCost === null) return res.status(400).json({ error: 'Service cost not cached. Refresh catalog.' });
  
  const customPrices = readDB('custom_prices.json') || {};
  let resellerCost;
  if (customPrices[serviceid]) {
    resellerCost = parseFloat(customPrices[serviceid].resellerPrice);
  } else {
    resellerCost = Math.ceil(realCost + settings.resellerMarkup);
  }
  
  const profit = resellerCost - realCost;
  const isReseller = user.role !== 'admin';
  const finalCostToDeduct = isReseller ? resellerCost : realCost;

  // 2. Check Virtual Balance (for all users, including Admin's personal balance)
  if (user.credits < finalCostToDeduct) {
    if (isReseller) {
      return res.status(400).json({ error: 'Saldo insuficiente. Contacte al administrador.' });
    } else {
      // Admin has insufficient balance. Check if they explicitly bypassed it.
      if (!req.body.bypassAdminBalance) {
        return res.status(400).json({ error: 'ADMIN_INSUFFICIENT_BALANCE', message: 'Saldo personal de Admin insuficiente.' });
      }
    }
  }

  const { apiaccesskey, masterUsername, endpoint } = settings;
  let targetUrl = endpoint || 'https://latamgsm.com/dhru/';
  if (!targetUrl.endsWith('/')) targetUrl += '/';
  if (!targetUrl.includes('/api/')) targetUrl += 'api/index.php';
  else if (targetUrl.endsWith('/api/')) targetUrl += 'index.php';

  try {
    // 3. Phantom Balance Safety Check (Verify Master Dhru Balance)
    const balParams = new URLSearchParams();
    balParams.append('username', masterUsername);
    balParams.append('apiaccesskey', apiaccesskey);
    balParams.append('action', 'accountinfo');
    balParams.append('requestformat', 'JSON');
    
    const balRes = await axios.post(targetUrl, balParams.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 10000
    });
    const masterDhruBalanceUSD = parseFloat(balRes.data?.SUCCESS?.[0]?.AccountInfo?.creditraw || 0);
    const masterDhruBalance = masterDhruBalanceUSD * 17.60;
    
    if (masterDhruBalance < realCost) {
      return res.status(500).json({ error: 'Error del servidor maestro (Sin saldo global).' });
    }

    // 4. Construct Order Request
    let customXml = '';
    if (custom_fields && typeof custom_fields === 'object' && Object.keys(custom_fields).length > 0) {
      const jsonStr = JSON.stringify(custom_fields);
      const base64Str = Buffer.from(jsonStr).toString('base64');
      customXml = `<CUSTOMFIELD>${base64Str}</CUSTOMFIELD>`;
    }

    // LatamGSM (Dhru 2025) unified all orders under the IMEI endpoints
    let action = 'placeimeiorder';
    let xmlParameters = serviceType === 'SERVER' 
      ? `<PARAMETERS><ID>${serviceid}</ID><QNT>1</QNT>${customXml}</PARAMETERS>`
      : `<PARAMETERS><ID>${serviceid}</ID><IMEI>${imei && imei.trim() !== '' ? imei : '111111111111111'}</IMEI>${customXml}</PARAMETERS>`;

    const params = new URLSearchParams();
    params.append('username', masterUsername);
    params.append('apiaccesskey', apiaccesskey);
    params.append('action', action);
    params.append('requestformat', 'JSON');
    params.append('parameters', xmlParameters);

    // 5. Send Order to Dhru
    const response = await axios.post(targetUrl, params.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 20000
    });

    if (response.data && response.data.SUCCESS) {
      // 6. On Success: Deduct balance & Route Profits
      // Deduct balance for EVERYONE (including Admin's personal pool)
      users[userIndex].credits -= finalCostToDeduct;
      
      if (isReseller) {
        settings.adminProfitBalance += profit;
      }
      
      writeDB('users.json', users);
      writeDB('settings.json', settings);
      
      const successItem = Array.isArray(response.data.SUCCESS) ? response.data.SUCCESS[0] : response.data.SUCCESS;
      const orderId = successItem.REFERENCEID || successItem.ORDERID || successItem.ID || 'Desconocido';
      const msg = successItem.MESSAGE || 'Exitoso';

      let imeiDataString = imei || 'N/A';
      if (custom_fields && typeof custom_fields === 'object') {
        const customKeys = Object.keys(custom_fields);
        if (customKeys.length > 0) {
          imeiDataString += ' (';
          customKeys.forEach((key, index) => {
            imeiDataString += `${key}: ${custom_fields[key]}${index < customKeys.length - 1 ? ', ' : ''}`;
          });
          imeiDataString += ')';
        }
      }

      // 7. Log Transaction Globally
      history.unshift({
        id: 'txn_' + Date.now(),
        userId: user.id,
        username: user.username,
        date: new Date().toISOString(),
        serviceId: serviceid,
        serviceName: serviceName || 'Servicio',
        serviceType: serviceType || 'IMEI',
        imei: imeiDataString,
        costCharged: finalCostToDeduct,
        realCost: realCost,
        profit: isReseller ? profit : 0,
        orderId,
        status: 'pending',
        msg
      });
      if (history.length > 500) history.pop();
      writeDB('history.json', history);

      return res.json(response.data);
    } else if (response.data && response.data.ERROR) {
      return res.json(response.data); // Return Dhru error straight to client
    } else {
      return res.status(500).json({ error: 'Respuesta inválida de Dhru al ordenar.' });
    }
  } catch (error) {
    return res.status(500).json({ error: 'Fallo al comunicarse con Dhru para ordenar.', details: error.message });
  }
});

// Get order status proxy endpoint
app.post('/api/order/status', requireAuth, async (req, res) => {
  const { orderid } = req.body;
  
  if (!orderid) {
    return res.status(400).json({ error: 'Order ID is required.' });
  }

  const settings = readDB('settings.json');
  if (!settings) return res.status(500).json({ error: 'Server misconfigured' });
  const { apiaccesskey, masterUsername, endpoint } = settings;

  let targetUrl = endpoint || 'https://latamgsm.com/dhru/';
  if (!targetUrl.endsWith('/')) targetUrl += '/';
  if (!targetUrl.includes('/api/')) targetUrl += 'api/index.php';
  else if (targetUrl.endsWith('/api/')) targetUrl += 'index.php';

  try {
    const params = new URLSearchParams();
    params.append('username', masterUsername);
    params.append('apiaccesskey', apiaccesskey);
    params.append('action', 'getimeiorder');
    params.append('requestformat', 'JSON');
    params.append('parameters', `<PARAMETERS><ID>${orderid}</ID></PARAMETERS>`);

    const response = await axios.post(targetUrl, params.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'User-Agent': 'Dhru-Fusion-Web-Client/1.0' },
      timeout: 15000
    });

    if (response.data) {
      return res.json(response.data);
    } else {
      return res.status(500).json({ error: 'No response data received from Dhru API.' });
    }
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch order status from Dhru API.', details: error.message });
  }
});

// Bulk order status proxy endpoint
app.post('/api/orders/bulk-status', requireAuth, async (req, res) => {
  const { ids, items } = req.body;
  if (!ids && !items) return res.status(400).json({ error: 'ids or items are required.' });

  const settings = readDB('settings.json');
  if (!settings) return res.status(500).json({ error: 'Server misconfigured' });
  const { apiaccesskey, masterUsername, endpoint } = settings;

  let targetUrl = endpoint || 'https://latamgsm.com/dhru/';
  if (!targetUrl.endsWith('/')) targetUrl += '/';
  if (!targetUrl.includes('/api/')) targetUrl += 'api/index.php';
  else if (targetUrl.endsWith('/api/')) targetUrl += 'index.php';

  try {
    let syncList = [];
    if (items && Array.isArray(items)) {
      syncList = items.filter(item => item && item.id);
    } else if (ids) {
      syncList = ids.split(',').map(id => ({ id: id.trim(), type: 'IMEI' })).filter(item => item.id);
    }

    const requests = syncList.map(async (itemObj) => {
      const orderid = itemObj.id;
      // LatamGSM (Dhru 2025) unifies everything under getimeiorder
      const action = 'getimeiorder';

      const params = new URLSearchParams();
      params.append('username', masterUsername);
      params.append('apiaccesskey', apiaccesskey);
      params.append('action', action);
      params.append('requestformat', 'JSON');
      params.append('parameters', `<PARAMETERS><ID>${orderid}</ID></PARAMETERS>`);

      try {
        let response = await axios.post(targetUrl, params.toString(), {
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15000
        });

        if (response.data && response.data.SUCCESS && response.data.SUCCESS.length > 0) {
          const item = response.data.SUCCESS[0];
          return {
            orderid: orderid,
            status: String(item.STATUS) === '4' ? 'success' : (String(item.STATUS) === '3' ? 'failed' : 'pending'),
            statusText: String(item.STATUS) === '4' ? (item.CODE || 'Completado') : (String(item.STATUS) === '3' ? 'Rechazado' : 'En proceso')
          };
        }
      } catch (err) {
        return { orderid, status: 'error', statusText: 'Fallo de conexión' };
      }
      return { orderid, status: 'unknown', statusText: 'Sin respuesta válida' };
    });

    const results = await Promise.all(requests);
    return res.json({ SUCCESS: results });
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch bulk statuses.', details: error.message });
  }
});

// History Endpoint
app.get('/api/history', requireAuth, (req, res) => {
  const history = readDB('history.json') || [];
  if (req.user.role === 'admin') {
    return res.json(history); // Admin sees everything
  } else {
    // Reseller sees only their own orders
    return res.json(history.filter(h => h.userId === req.user.id));
  }
});

// --- ADMIN ENDPOINTS ---

// Manage Users (Admin Only)
app.get('/api/users', requireAuth, requireAdmin, (req, res) => {
  const users = readDB('users.json') || [];
  // Return users without exposing passwords
  res.json(users.map(u => ({ id: u.id, username: u.username, role: u.role, credits: u.credits, createdAt: u.createdAt })));
});

app.post('/api/users', requireAuth, requireAdmin, (req, res) => {
  const { username, password, credits, role } = req.body;
  const users = readDB('users.json') || [];
  if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(400).json({ error: 'Username already exists' });
  }
  const newUser = {
    id: Date.now(),
    username,
    password,
    role: role || 'reseller',
    credits: parseFloat(credits) || 0,
    createdAt: new Date().toISOString()
  };
  users.push(newUser);
  writeDB('users.json', users);
  res.json(newUser);
});

app.put('/api/users/:id', requireAuth, requireAdmin, (req, res) => {
  const { credits, password } = req.body;
  const users = readDB('users.json') || [];
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (credits !== undefined) user.credits = parseFloat(credits);
  if (password) user.password = password;

  writeDB('users.json', users);
  res.json(user);
});

app.delete('/api/users/:id', requireAuth, requireAdmin, (req, res) => {
  const users = readDB('users.json') || [];
  if (parseInt(req.params.id) === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
  
  const newUsers = users.filter(u => u.id !== parseInt(req.params.id));
  writeDB('users.json', newUsers);
  res.json({ success: true });
});

// Admin Dashboard Stats
app.get('/api/admin/stats', requireAuth, requireAdmin, (req, res) => {
  const settings = readDB('settings.json') || {};
  res.json({ profitBalance: settings.adminProfitBalance || 0 });
});

// Admin Settings
app.get('/api/admin/settings', requireAuth, requireAdmin, (req, res) => {
  const settings = readDB('settings.json') || {};
  res.json({
    resellerMarkup: settings.resellerMarkup || 0,
    clientMarkup: settings.clientMarkup || 0
  });
});

app.post('/api/admin/settings', requireAuth, requireAdmin, (req, res) => {
  const settings = readDB('settings.json') || {};
  if (req.body.resellerMarkup !== undefined) {
    settings.resellerMarkup = parseFloat(req.body.resellerMarkup) || 0;
  }
  if (req.body.clientMarkup !== undefined) {
    settings.clientMarkup = parseFloat(req.body.clientMarkup) || 0;
  }
  writeDB('settings.json', settings);
  res.json({ success: true, settings });
});

// Admin Custom Product Prices
app.post('/api/admin/product-price', requireAuth, requireAdmin, (req, res) => {
  const customPrices = readDB('custom_prices.json') || {};
  
  if (Array.isArray(req.body.bulk)) {
    req.body.bulk.forEach(item => {
      if (item.serviceId && item.resellerPrice !== undefined && item.clientPrice !== undefined) {
        customPrices[item.serviceId] = {
          resellerPrice: parseFloat(item.resellerPrice),
          clientPrice: parseFloat(item.clientPrice)
        };
      }
    });
  } else {
    const { serviceId, resellerPrice, clientPrice } = req.body;
    if (!serviceId || resellerPrice === undefined || clientPrice === undefined) {
      return res.status(400).json({ error: 'Missing parameters' });
    }
    customPrices[serviceId] = {
      resellerPrice: parseFloat(resellerPrice),
      clientPrice: parseFloat(clientPrice)
    };
  }
  
  writeDB('custom_prices.json', customPrices);
  res.json({ success: true });
});

app.delete('/api/admin/product-price/:id', requireAuth, requireAdmin, (req, res) => {
  const customPrices = readDB('custom_prices.json') || {};
  if (customPrices[req.params.id]) {
    delete customPrices[req.params.id];
    writeDB('custom_prices.json', customPrices);
  }
  res.json({ success: true });
});

// Debug endpoint to write client history to disk
app.post('/api/debug/history', (req, res) => {
  const fs = require('fs');
  fs.writeFileSync(path.join(__dirname, 'client_history_debug.json'), JSON.stringify(req.body, null, 2));
  return res.json({ success: true });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`==================================================`);
  console.log(`Dhru Fusion Web Client running at http://localhost:${PORT}`);
  console.log(`==================================================`);
});
