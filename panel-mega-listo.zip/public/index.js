document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide icons
  lucide.createIcons();

  // DOM Elements - Views
  const loginView = document.getElementById('loginView');
  const dashboardView = document.getElementById('dashboardView');

  // DOM Elements - Auth & Header
  const credentialsForm = document.getElementById('credentialsForm');
  const usernameInput = document.getElementById('usernameInput');
  const passwordInput = document.getElementById('passwordInput');
  const btnTogglePass = document.getElementById('btnTogglePass');
  const connectionStatus = document.getElementById('connectionStatus');
  const btnLogout = document.getElementById('btnLogout');
  const btnAdminManage = document.getElementById('btnAdminManage');
  const btnRechargeBalance = document.getElementById('btnRechargeBalance');
  const creditsBadgeContainer = document.getElementById('creditsBadgeContainer');
  const creditsBalanceText = document.getElementById('creditsBalanceText');
  const filterTypeSelect = document.getElementById('filterTypeSelect');
  const filterGroupSelect = document.getElementById('filterGroupSelect');
  const filterServiceSelect = document.getElementById('filterServiceSelect');
  const btnAdvancedSearch = document.getElementById('btnAdvancedSearch');
  const categoriesGrid = document.getElementById('categoriesGrid');
  const btnBackToCategories = document.getElementById('btnBackToCategories');
  const catalogTitle = document.getElementById('catalogTitle');
  const tabCatalog = document.getElementById('tabCatalog');
  const tabHistory = document.getElementById('tabHistory');
  const productsSection = document.getElementById('productsSection');
  const historySection = document.getElementById('historySection');
  
  const productCount = document.getElementById('productCount');
  const feedbackArea = document.getElementById('feedbackArea');
  const productsBody = document.getElementById('productsBody');
  // DOM Elements - History Reseller Panel
  const historyCount = document.getElementById('historyCount');
  const historyBody = document.getElementById('historyBody');
  const btnClearHistory = document.getElementById('btnClearHistory');
  const btnSyncHistory = document.getElementById('btnSyncHistory');
  const historyLimitFilter = document.getElementById('historyLimitFilter');
  const historySearchInput = document.getElementById('historySearchInput');

  // DOM Elements - Debug Console
  const consoleCount = document.getElementById('consoleCount');
  const consoleEmpty = document.getElementById('consoleEmpty');
  const consoleList = document.getElementById('consoleList');
  const btnClearConsole = document.getElementById('btnClearConsole');
  const btnBulkSavePrices = document.getElementById('btnBulkSavePrices');

  // DOM Elements - Modal
  const purchaseModal = document.getElementById('purchaseModal');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const btnCancelOrder = document.getElementById('btnCancelOrder');
  const orderForm = document.getElementById('orderForm');
  const imeiInput = document.getElementById('imeiInput');
  const modalServiceId = document.getElementById('modalServiceId');
  const modalServiceName = document.getElementById('modalServiceName');
  const modalServiceGroup = document.getElementById('modalServiceGroup');
  const modalServicePrice = document.getElementById('modalServicePrice');
  const customFieldsContainer = document.getElementById('customFieldsContainer');
  const imeiInputGroup = document.getElementById('imeiInputGroup');
  const imeiAutoGenerate = document.getElementById('imeiAutoGenerate');
  const imeiInputWrapper = document.getElementById('imeiInputWrapper');
  const imeiHint = document.getElementById('imeiHint');
  const imeiLabel = document.getElementById('imeiLabel');
  
  const modalBalanceWarning = document.getElementById('modalBalanceWarning');
  const modalServiceInfoBlock = document.getElementById('modalServiceInfoBlock');
  const modalServiceTime = document.getElementById('modalServiceTime');
  const modalServiceInfoText = document.getElementById('modalServiceInfoText');
  const btnConfirmOrder = document.getElementById('btnConfirmOrder');

  // DOM Elements - Ticket Generator
  const ticketModal = document.getElementById('ticketModal');
  const btnTicketClose = document.getElementById('btnTicketClose');
  const btnCancelTicket = document.getElementById('btnCancelTicket');
  const btnGenerateTicketFinal = document.getElementById('btnGenerateTicketFinal');
  const ticketClientPrice = document.getElementById('ticketClientPrice');
  
  const ticketTemplateContainer = document.getElementById('ticketTemplateContainer');
  const ticketTemplate = document.getElementById('ticketTemplate');
  const ticketTitle = document.getElementById('ticketTitle');
  const ticketUserVal = document.getElementById('ticketUserVal');
  const ticketPassVal = document.getElementById('ticketPassVal');
  const ticketPricePill = document.getElementById('ticketPricePill');
  const ticketPriceVal = document.getElementById('ticketPriceVal');
  
  // New ticket template elements
  const ticketFormatType = document.getElementById('ticketFormatType');
  const ticketParsedBox = document.getElementById('ticketParsedBox');
  const ticketRawBox = document.getElementById('ticketRawBox');
  const ticketRawTextVal = document.getElementById('ticketRawTextVal');

  let currentTicketData = null;

  // Application State
  let productsList = [];
  let uniqueGroups = new Set();
  let exchangeRate = 17.60103; // Exact API Rate (MXN / USD) to match LatamGSM panel
  let globalApiCurrency = 'MXN'; // Hardcoded to MXN since backend converts all prices
  let globalApiCreditRaw = 0; // Store the raw user credit balance for comparison

  let selectedProductForOrder = null;
  let orderHistory = [];
  let consoleLogList = [];

  let authToken = null;
  let authRole = null;
  let authUsername = null;

  // Load Persisted Session
  function checkPersistedSession() {
    authToken = localStorage.getItem('dhru_token');
    authRole = localStorage.getItem('dhru_role');
    authUsername = localStorage.getItem('dhru_username');
    // We no longer load history from local storage. It is fetched from the backend on login.

    if (authToken) {
      loginView.classList.add('hidden');
      dashboardView.classList.remove('hidden');
      btnLogout.classList.remove('hidden');
      if (authRole === 'admin') {
        btnAdminManage.classList.remove('hidden');
        // Inject admin headers to history table
        const historyHead = document.querySelector('#historySection thead tr');
        if (historyHead && !historyHead.dataset.adminInjected) {
          historyHead.dataset.adminInjected = 'true';
          const thUser = document.createElement('th');
          thUser.textContent = 'Usuario';
          const thProfit = document.createElement('th');
          thProfit.textContent = 'Ganancia';
          historyHead.insertBefore(thUser, historyHead.children[2]);
          historyHead.appendChild(thProfit);
        }
      } else {
        btnRechargeBalance.classList.remove('hidden');
      }
      
      syncProducts(true);
      updateAccountCredits();
      fetchOrderHistory();
    }
  }
  checkPersistedSession();

  async function fetchOrderHistory() {
    if (!authToken) return;
    try {
      const res = await fetch('/api/history', {
        headers: { 'Authorization': `Bearer ${authToken}` }
      });
      if (res.ok) {
        orderHistory = await res.json();
        renderOrderHistory();
      }
    } catch (e) {
      console.warn('Failed to fetch history', e);
    }
  }

  // Toggle Password visibility
  btnTogglePass.addEventListener('click', () => {
    const isPassword = passwordInput.type === 'password';
    passwordInput.type = isPassword ? 'text' : 'password';
    btnTogglePass.innerHTML = `<i data-lucide="${isPassword ? 'eye-off' : 'eye'}"></i>`;
    lucide.createIcons();
  });

  // Handle Login Form Submission
  credentialsForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    if (!username || !password) {
      alert('Por favor completa todos los campos.');
      return;
    }

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      
      if (res.ok) {
        authToken = data.token;
        authRole = data.role;
        authUsername = data.username;
        localStorage.setItem('dhru_token', authToken);
        localStorage.setItem('dhru_role', authRole);
        localStorage.setItem('dhru_username', authUsername);

        loginView.classList.add('hidden');
        dashboardView.classList.remove('hidden');
        btnLogout.classList.remove('hidden');
        if (authRole === 'admin') {
          btnAdminManage.classList.remove('hidden');
          btnBulkSavePrices.classList.remove('hidden');
        }
        else btnRechargeBalance.classList.remove('hidden');

        syncProducts(true);
        updateAccountCredits();
        fetchOrderHistory();
      } else {
        alert(data.error || 'Error al iniciar sesión');
      }
    } catch (err) {
      alert('Error de red al iniciar sesión');
    }
  });

  // Setup back button
  btnBackToCategories.addEventListener('click', () => {
    if (filterTypeSelect) filterTypeSelect.value = 'all';
    if (filterGroupSelect) {
       filterGroupSelect.innerHTML = '<option value="all">Todos los grupos</option>';
       filterGroupSelect.value = 'all';
    }
    if (filterServiceSelect) {
       filterServiceSelect.innerHTML = '<option value="">Selecciona una opción</option>';
       filterServiceSelect.value = '';
    }
    showCategoriesView();
  });

  // Setup Tabs
  tabCatalog.addEventListener('click', () => {
    tabCatalog.classList.add('active');
    tabHistory.classList.remove('active');
    productsSection.classList.remove('hidden');
    historySection.classList.add('hidden');
  });

  tabHistory.addEventListener('click', () => {
    tabHistory.classList.add('active');
    tabCatalog.classList.remove('active');
    historySection.classList.remove('hidden');
    productsSection.classList.add('hidden');
    fetchOrderHistory(); // Refresh history every time the tab is opened
  });

  // Setup IMEI Toggle
  imeiAutoGenerate.addEventListener('change', () => {
    if (imeiAutoGenerate.checked) {
      imeiInputWrapper.classList.add('hidden');
      imeiHint.classList.add('hidden');
      imeiInput.required = false;
      imeiLabel.style.opacity = '0.5';
    } else {
      imeiInputWrapper.classList.remove('hidden');
      imeiHint.classList.remove('hidden');
      imeiInput.required = true;
      imeiLabel.style.opacity = '1';
    }
  });

  // Logout Logic
  btnLogout.addEventListener('click', () => {
    localStorage.removeItem('dhru_username');
    localStorage.removeItem('dhru_endpoint');

    productsList = [];
    productsBody.innerHTML = '';
    productCount.textContent = '0';

    consoleLogList = [];
    renderConsoleLogs();

    dashboardView.classList.add('hidden');
    btnLogout.classList.add('hidden');
    loginView.classList.remove('hidden');
    creditsBadgeContainer.classList.add('hidden');

    updateStatus('offline', 'Sin conectar');
    // apiKeyInput.value = '';
  });

  // Clear History
  btnClearHistory.addEventListener('click', () => {
    if (confirm('¿Estás seguro de que deseas limpiar el historial de pedidos?')) {
      orderHistory = [];
      localStorage.removeItem('dhru_order_history');
      renderOrderHistory();
    }
  });

  // Clear Console
  btnClearConsole.addEventListener('click', () => {
    consoleLogList = [];
    renderConsoleLogs();
  });
  // Synchronize Order History Statuses
  btnSyncHistory.addEventListener('click', async () => {
    if (!authToken) {
      alert('Faltan credenciales en la sesión.');
      return;
    }

    // Send the current history state to the server for debugging
    try {
      await fetch('/api/debug/history', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderHistory, consoleLogList })
      });
    } catch (e) {
      console.warn('Failed to post debug history', e);
    }

    // Let's sync ALL orders that have a valid order ID and whose statusText contains a placeholder message
    const pendingOrders = orderHistory.filter(o => {
      if (!o.orderId || o.orderId === 'Error') return false;
      const isPending = o.status === 'pending';
      const isSuccess = o.status === 'success';
      const txt = String(o.statusText || '').toLowerCase();
      // If it's pending OR if it contains placeholder text, we sync it!
      return isPending || isSuccess || !txt || txt.includes('received') || txt.includes('espera') || txt === 'exitoso';
    });

    if (pendingOrders.length === 0) {
      alert('No hay pedidos pendientes por sincronizar en el historial.');
      return;
    }

    btnSyncHistory.setAttribute('disabled', 'true');
    btnSyncHistory.querySelector('span').textContent = 'Sincronizando...';

    let updatedCount = 0;

    const itemsToSync = pendingOrders.map(o => {
      let t = o.serviceType;
      if (!t) {
        const matchingProduct = productsList.find(p => String(p.serviceid) === String(o.serviceId));
        if (matchingProduct && matchingProduct.serviceType === 'SERVER') {
          t = 'SERVER';
        } else {
          t = 'IMEI';
        }
      }
      return { id: o.orderId, type: t };
    });
    
    try {
      const payload = { items: itemsToSync };
      
      const res = await fetch('/api/orders/bulk-status', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(payload)
      });
      
      const data = await res.json();
      logApiCall(`getorderbulk [Count: ${itemsToSync.length}]`, payload, data, res.ok);
      
      if (res.status === 401) {
        alert('Sesión caducada (401). Por favor, vuelve a iniciar sesión.');
        logout();
        return;
      }
      
      if (res.ok && data.SUCCESS && Array.isArray(data.SUCCESS)) {
        for (const apiOrderWrapper of data.SUCCESS) {
          let apiOrder = apiOrderWrapper.DATA || apiOrderWrapper.data || apiOrderWrapper;
          
          const orderIdToCheck = String(apiOrder.orderid || apiOrder.requested_id || apiOrder.ID || apiOrder.id || apiOrder.REFERENCEID || apiOrder.referenceid || '');
          const localOrder = orderHistory.find(o => String(o.orderId) === orderIdToCheck);
          
          if (localOrder) {
            const orderStatus = String(apiOrder.STATUS || apiOrder.status || '').toLowerCase();
            const replyCode = apiOrder.statusText || apiOrder.CODE || apiOrder.code || apiOrder.REPLY || apiOrder.reply || '';
            
            const isRejected = orderStatus === '3' || 
                               orderStatus === 'failed' || 
                               orderStatus === 'rejected' ||
                               orderStatus === 'error' ||
                               orderStatus === 'cancel' ||
                               orderStatus === 'canceled' ||
                               orderStatus === 'cancelled';

            const isCompleted = orderStatus === '4' || 
                                orderStatus === 'completed' || 
                                orderStatus === 'success';
                                
            if (isRejected && localOrder.status !== 'failed') {
              localOrder.status = 'failed';
              localOrder.statusText = replyCode || apiOrder.MESSAGE || apiOrder.message || 'Rechazado';
              localOrder.updateTimestamp = new Date().toLocaleString('es-MX');
              updatedCount++;
            } else if (isCompleted && localOrder.status !== 'success') {
              localOrder.status = 'success';
              localOrder.statusText = replyCode || apiOrder.MESSAGE || apiOrder.message || 'Completado';
              localOrder.updateTimestamp = new Date().toLocaleString('es-MX');
              updatedCount++;
            } else if (replyCode && localOrder.status === 'pending') {
              localOrder.statusText = replyCode;
            }
          }
        }
      }
    } catch (err) {
      console.error(`Error in bulk sync:`, err);
    }

    // Persist updated history
    localStorage.setItem('dhru_order_history', JSON.stringify(orderHistory));
    renderOrderHistory();

    btnSyncHistory.removeAttribute('disabled');
    btnSyncHistory.querySelector('span').textContent = 'Sincronizar Pedidos';
    lucide.createIcons();
    
    updateAccountCredits();

    alert(`Sincronización finalizada. Se actualizaron ${updatedCount} pedidos.`);
  });

  // Update Account Credits
  async function updateAccountCredits() {
    if (!authToken) return;
    try {
      const res = await fetch('/api/account', {
        method: 'GET',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.SUCCESS && data.SUCCESS.length > 0) {
          const info = data.SUCCESS[0];
          const rawCredits = parseFloat(info.CREDIT || '0');
          globalApiCreditRaw = rawCredits;
          
          creditsBadgeContainer.classList.remove('hidden');
          
          if (info.IS_ADMIN) {
            const assigned = parseFloat(info.ASSIGNED || '0').toFixed(2);
            const available = parseFloat(info.AVAILABLE || '0').toFixed(2);
            creditsBalanceText.innerHTML = `
              <div style="display: flex; gap: 15px; font-size: 0.9rem;">
                <span title="Saldo Real del Servidor" style="color: #10b981;">🟢 Real: $${rawCredits.toFixed(2)}</span>
                <span title="Saldo Cedido a Usuarios" style="color: #c4b5fd;">🟣 Cedido: $${assigned}</span>
                <span title="Saldo Disponible para usar" style="color: #22d3ee;">🔵 Disp: $${available}</span>
              </div>
            `;
          } else {
            creditsBalanceText.textContent = `Créditos: $${rawCredits.toFixed(2)}`;
          }
        }
      }
    } catch (e) {
      console.warn('Failed to fetch account credits balance', e);
    }
  }

  // Sychronize Products implementation
  async function syncProducts(shouldPersist = false) {
    if (!authToken) return;

    setLoadingState(true);
    updateStatus('loading', 'Sincronizando...');

    try {
      const response = await fetch('/api/products', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        }
      });

      const data = await response.json();

      if (!response.ok) {
        if (response.status === 401) {
          alert('Tu sesión ha expirado o el servidor se reinició. Por favor, inicia sesión de nuevo.');
          btnLogout.click();
          return;
        }
        logApiCall('imeiservicelist', {}, data, false);
        const detailedError = data.details ? (typeof data.details === 'object' ? JSON.stringify(data.details) : data.details) : '';
        throw new Error((data.error || 'Error al comunicarse con la API.') + (detailedError ? ` Detalles: ${detailedError}` : ''));
      }

      if (data.ERROR && data.ERROR.length > 0) {
        logApiCall('imeiservicelist', {}, data, false);
        const errMsg = typeof data.ERROR[0] === 'object' ? (data.ERROR[0].MESSAGE || JSON.stringify(data.ERROR[0])) : data.ERROR[0];
        throw new Error(`Dhru API Error: ${errMsg}`);
      }

      if (!data.SUCCESS) {
        logApiCall('imeiservicelist', {}, data, false);
        throw new Error('La respuesta de la API no contiene el formato esperado.');
      }

      logApiCall('imeiservicelist', {}, data, true);

      productsList = [];
      uniqueGroups.clear();

      if (Array.isArray(data.SUCCESS) && data.SUCCESS.length > 0 && data.SUCCESS[0].LIST) {
        const listObj = data.SUCCESS[0].LIST;
        for (const groupKey in listObj) {
          const group = listObj[groupKey];
          const groupName = group.GROUPNAME || groupKey;
          const groupType = group.GROUPTYPE || 'General';
          if (group.SERVICES && typeof group.SERVICES === 'object') {
            for (const serviceId in group.SERVICES) {
              const item = group.SERVICES[serviceId];
              productsList.push({
                serviceid: item.SERVICEID || serviceId,
                service: item.SERVICENAME || item.SERVICE || 'Sin nombre',
                group: groupName,
                type: groupType || item.SERVICETYPE || item.TYPE || 'General',
                serviceType: item._SERVICE_TYPE || 'IMEI', // IMPORTANT: Store the backend type (IMEI or SERVER)
                credit: item.CREDIT || '0.00',
                time: item.TIME || 'N/A',
                rawItem: item
              });
            }
          }
        }
      } else if (Array.isArray(data.SUCCESS)) {
        productsList = data.SUCCESS.map(item => ({
          serviceid: item.SERVICEID || item.serviceid || 'N/A',
          service: item.SERVICENAME || item.SERVICE || item.service || 'Sin nombre',
          group: item.GROUP || item.group || 'General',
          type: item.GROUPTYPE || item.SERVICETYPE || item.TYPE || item.type || 'General',
          credit: item.CREDIT || item.credit || '0.00',
          time: item.TIME || item.time || 'N/A',
          rawItem: item
        }));
      } else if (typeof data.SUCCESS === 'object' && data.SUCCESS !== null) {
        for (const groupName in data.SUCCESS) {
          if (Array.isArray(data.SUCCESS[groupName])) {
            data.SUCCESS[groupName].forEach(item => {
              productsList.push({
                serviceid: item.SERVICEID || item.serviceid || 'N/A',
                service: item.SERVICENAME || item.SERVICE || item.service || 'Sin nombre',
                group: groupName || 'General',
                type: item.GROUPTYPE || item.SERVICETYPE || item.TYPE || item.type || 'General',
                credit: item.CREDIT || item.credit || '0.00',
                time: item.TIME || item.time || 'N/A',
                rawItem: item
              });
            });
          }
        }
      }


      productsList.forEach(p => {
        if (p.group) uniqueGroups.add(p.group);
      });

      initAdvancedFilters();
      renderProducts(productsList);
      renderOrderHistory();
      
      updateStatus('online', 'Conectado');
      setLoadingState(false);

    } catch (err) {
      console.error(err);
      showError(err.message);
      updateStatus('offline', 'Error de conexión');
      setLoadingState(false);
    }
  }

  // Advanced Filters Logic
  function initAdvancedFilters() {
    if (!filterTypeSelect || !filterGroupSelect || !filterServiceSelect) return;

    // 1. Get unique types
    const types = [...new Set(productsList.map(p => p.type))].filter(Boolean).sort();
    
    // 2. Populate Type Select
    filterTypeSelect.innerHTML = '<option value="all">Todos los tipos</option>';
    types.forEach(type => {
      const option = document.createElement('option');
      option.value = type;
      // Beautiful labels based on type
      let label = type;
      const typeLower = type.toLowerCase();
      if (typeLower.includes('imei')) label = '📱 SERVICIOS IMEI';
      else if (typeLower.includes('server')) label = '🖥️ SERVICIO REMOTO';
      else if (typeLower.includes('file')) label = '📄 SERVICIO DE ARCHIVOS';
      else if (typeLower.includes('activation') || typeLower.includes('credit')) label = '⚡ CRÉDITOS | ACTIVACIONES';
      
      option.textContent = label;
      filterTypeSelect.appendChild(option);
    });

    // 3. Initial populations
    populateGroupsFilter('all');
    populateServicesFilter('all', 'all');

    // 4. Cascade Events
    if (!filterTypeSelect.dataset.listenerBound) {
      filterTypeSelect.addEventListener('change', (e) => {
        populateGroupsFilter(e.target.value);
        populateServicesFilter(e.target.value, 'all');
      });

      filterGroupSelect.addEventListener('change', (e) => {
        populateServicesFilter(filterTypeSelect.value, e.target.value);
      });
      filterTypeSelect.dataset.listenerBound = 'true';
    }
    
    syncTomSelect(filterTypeSelect);
  }

  let tsInstances = {};
  function syncTomSelect(el) {
    if (!el || typeof TomSelect === 'undefined') return;
    if (tsInstances[el.id]) {
      tsInstances[el.id].destroy();
    }
    tsInstances[el.id] = new TomSelect(el, {
      create: false,
      maxOptions: null,
      dropdownParent: 'body',
      controlInput: '<input placeholder="Buscar...">'
    });
  }

  function populateGroupsFilter(typeFilter) {
    let filteredProducts = productsList;
    if (typeFilter !== 'all') {
      filteredProducts = productsList.filter(p => p.type === typeFilter);
    }
    const groups = [...new Set(filteredProducts.map(p => p.group))].filter(Boolean).sort();
    
    filterGroupSelect.innerHTML = '<option value="all">Todos los grupos</option>';
    groups.forEach(group => {
      const option = document.createElement('option');
      option.value = group;
      option.textContent = group;
      filterGroupSelect.appendChild(option);
    });
    
    syncTomSelect(filterGroupSelect);
  }

  function populateServicesFilter(typeFilter, groupFilter) {
    let filteredProducts = productsList;
    if (typeFilter !== 'all') {
      filteredProducts = filteredProducts.filter(p => p.type === typeFilter);
    }
    if (groupFilter !== 'all') {
      filteredProducts = filteredProducts.filter(p => p.group === groupFilter);
    }
    
    // Sort alphabetically by service name
    filteredProducts.sort((a, b) => a.service.localeCompare(b.service));

    filterServiceSelect.innerHTML = '<option value="">Selecciona una opción</option>';
    filteredProducts.forEach(product => {
      const option = document.createElement('option');
      option.value = product.serviceid;
      // Add price for better UX
      option.textContent = `${product.service} - ${formatPrice(product.credit)}`;
      filterServiceSelect.appendChild(option);
    });
    
    syncTomSelect(filterServiceSelect);
  }

  // Handle Search Button Click
  if (btnAdvancedSearch) {
    btnAdvancedSearch.addEventListener('click', () => {
      const typeFilter = filterTypeSelect.value;
      const groupFilter = filterGroupSelect.value;
      const serviceIdFilter = filterServiceSelect.value;
      
      let filtered = productsList;
      
      if (serviceIdFilter) {
         // Direct service selected
         filtered = productsList.filter(p => String(p.serviceid) === String(serviceIdFilter));
      } else {
         // Filter by type and group
         if (typeFilter !== 'all') filtered = filtered.filter(p => p.type === typeFilter);
         if (groupFilter !== 'all') filtered = filtered.filter(p => p.group === groupFilter);
      }
      
      if (filtered.length === 0) {
        productsBody.innerHTML = `
          <div class="empty-state" style="grid-column: 1 / -1;">
            <i data-lucide="search-code"></i>
            <h3>No se encontraron productos</h3>
          </div>
        `;
        lucide.createIcons();
      } else {
        renderProductCards(filtered);
      }

      categoriesGrid.classList.add('hidden');
      productsBody.classList.remove('hidden');
      btnBackToCategories.classList.remove('hidden');
      catalogTitle.textContent = 'Resultados de Búsqueda';
    });
  }

  // Handle direct Service selection trigger
  if (filterServiceSelect) {
    filterServiceSelect.addEventListener('change', () => {
       if (filterServiceSelect.value !== '') {
         // Optionally auto-search when a specific service is picked
         btnAdvancedSearch.click();
       }
    });
  }
  
  // Handle Global Text Search
  const globalProductSearch = document.getElementById('globalProductSearch');
  if (globalProductSearch) {
    globalProductSearch.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase().trim();
      if (!q) {
        showCategoriesView();
        return;
      }
      
      const filtered = productsList.filter(p => 
        String(p.service).toLowerCase().includes(q) || 
        String(p.serviceid).toLowerCase().includes(q)
      );
      
      if (filtered.length === 0) {
        productsBody.innerHTML = `
          <div class="empty-state" style="grid-column: 1 / -1;">
            <i data-lucide="search-code"></i>
            <h3>No se encontraron productos</h3>
          </div>
        `;
        lucide.createIcons();
      } else {
        renderProductCards(filtered);
      }

      categoriesGrid.classList.add('hidden');
      productsBody.classList.remove('hidden');
      btnBackToCategories.classList.remove('hidden');
      catalogTitle.textContent = `Resultados para "${q}"`;
    });
  }

  // Render products into the table
  function renderProducts(products) {
    productsBody.innerHTML = '';
    productCount.textContent = products.length;

    if (!products || products.length === 0) {
      feedbackArea.innerHTML = `
        <div class="empty-state">
          <i data-lucide="search-code"></i>
          <h3>No se encontraron productos</h3>
        </div>
      `;
      feedbackArea.classList.remove('hidden');
      productsBody.classList.add('hidden');
      categoriesGrid.classList.add('hidden');
      lucide.createIcons();
      return;
    }

    feedbackArea.classList.add('hidden');
    categoriesGrid.parentElement.classList.remove('hidden');
    
    // Group products by category
    const grouped = {};
    products.forEach(p => {
      let gName = p.group || 'Otros Servicios';
      
      // Normalize AT&T groups into a single group
      const gnLower = gName.toLowerCase();
      if (gnLower.includes('att') || gnLower.includes('at&t') || gnLower.includes('at&amp;t')) {
        gName = 'Desbloqueos AT&T (USA / MX)';
      }
      
      if (!grouped[gName]) grouped[gName] = [];
      grouped[gName].push(p);
    });

    categoriesGrid.innerHTML = '';

    // Sort categories: "Hot" first, then alphabetical
    const entries = Object.entries(grouped);
    entries.sort((a, b) => {
      const isHotA = isHotCategory(a[0]);
      const isHotB = isHotCategory(b[0]);
      if (isHotA && !isHotB) return -1;
      if (!isHotA && isHotB) return 1;
      return a[0].localeCompare(b[0]);
    });

    for (const [groupName, items] of entries) {
      const tile = document.createElement('div');
      tile.className = 'category-tile';
      
      const isHot = isHotCategory(groupName);
      if (isHot) tile.classList.add('hot-category');
      
      // Determine icon based on group name
      let icon = 'layers';
      const gn = groupName.toLowerCase();
      if (gn.includes('renta') || gn.includes('server')) icon = 'server';
      else if (gn.includes('imei') || gn.includes('unlock')) icon = 'smartphone';
      else if (gn.includes('licencia') || gn.includes('activa')) icon = 'key';
      else if (gn.includes('apple') || gn.includes('iphone')) icon = 'smartphone';
      
      let hotBadgeHtml = isHot ? '<span class="hot-badge">🔥 HOT</span>' : '';
      
      tile.innerHTML = `
        ${hotBadgeHtml}
        <i data-lucide="${icon}"></i>
        <h3>${escapeHtml(groupName)}</h3>
        <span class="category-count">${items.length} Servicios</span>
      `;
      
      tile.addEventListener('click', () => {
        showCategoryProducts(groupName, items);
      });
      
      categoriesGrid.appendChild(tile);
    }
    
    showCategoriesView();
  }
  
  function isHotCategory(groupName) {
    const gn = groupName.toLowerCase();
    return gn.includes('renta') || gn.includes('check') || gn.includes('at&t') || gn.includes('att');
  }
  
  function showCategoriesView() {
    categoriesGrid.classList.remove('hidden');
    productsBody.classList.add('hidden');
    btnBackToCategories.classList.add('hidden');
    catalogTitle.textContent = 'Catálogo de Productos';
    lucide.createIcons();
  }

  function showCategoryProducts(groupName, items) {
    categoriesGrid.classList.add('hidden');
    productsBody.classList.remove('hidden');
    btnBackToCategories.classList.remove('hidden');
    catalogTitle.textContent = groupName;
    
    renderProductCards(items);
  }

  function renderProductCards(items) {
    productsBody.innerHTML = '';
    
    items.forEach(p => {
      const priceText = formatPrice(p.credit);
      
      let adminPricesHtml = '';
      let adminCustomPriceHtml = '';
      if (authRole === 'admin') {
        const real = formatPrice(p.rawItem._REAL_COST || '0');
        const client = formatPrice(p.rawItem._CLIENT_PRICE || '0');
        adminPricesHtml = `
          <div style="font-size: 0.8rem; margin-top: 5px; background: rgba(0,0,0,0.2); padding: 5px; border-radius: 4px;">
            <div style="color: #10b981; margin-bottom: 2px;">Costo API: <strong>${real}</strong></div>
            <div style="color: #c4b5fd;">Precio Cliente: <strong>${client}</strong></div>
          </div>
        `;
        
        adminCustomPriceHtml = `
          <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.1);">
            <h4 style="margin-top: 0; margin-bottom: 10px; color: #f472b6; font-size: 0.9rem; display: flex; align-items: center; gap: 5px;">
              <i data-lucide="edit-3" style="width: 14px; height: 14px;"></i> Asignar Precio Manual
            </h4>
            <form class="custom-price-form" data-id="${escapeHtml(p.serviceid)}" style="display: flex; gap: 8px; align-items: flex-end; flex-wrap: wrap;">
              <div class="input-group" style="flex: 1; min-width: 100px; margin-bottom: 0;">
                <label style="font-size: 0.75rem; margin-bottom: 3px;">Precio Reseller (MXN)</label>
                <input type="number" step="0.01" class="custom-reseller-input admin-price-input" data-id="${escapeHtml(p.serviceid)}" data-type="reseller" value="${p.credit}" style="padding: 6px; font-size: 0.85rem;" required>
              </div>
              <div class="input-group" style="flex: 1; min-width: 100px; margin-bottom: 0;">
                <label style="font-size: 0.75rem; margin-bottom: 3px;">Precio Cliente (MXN)</label>
                <input type="number" step="0.01" class="custom-client-input admin-price-input" data-id="${escapeHtml(p.serviceid)}" data-type="client" value="${p.rawItem._CLIENT_PRICE || '0'}" style="padding: 6px; font-size: 0.85rem;" required>
              </div>
              <div style="display: flex; gap: 5px;">
                <button type="submit" class="btn btn-primary" style="padding: 6px 10px; font-size: 0.8rem;" title="Guardar Precio Fijo">
                  <i data-lucide="save" style="width: 14px; height: 14px; margin: 0;"></i>
                </button>
                <button type="button" class="btn btn-secondary btn-reset-price" data-id="${escapeHtml(p.serviceid)}" style="padding: 6px 10px; font-size: 0.8rem;" title="Restablecer (Auto)">
                  <i data-lucide="refresh-cw" style="width: 14px; height: 14px; margin: 0;"></i>
                </button>
              </div>
            </form>
          </div>
        `;
      }
      
      const card = document.createElement('div');
      card.className = 'product-card';
      
      card.innerHTML = `
        <div class="product-card-header">
          <span class="product-id">ID: ${escapeHtml(p.serviceid)}</span>
        </div>
        <h3 class="product-title">${escapeHtml(p.service)}</h3>
        <div class="product-details">
          <div class="detail-row">
            <i data-lucide="clock"></i> <span>${escapeHtml(p.time)}</span>
          </div>
          <div class="detail-row" style="align-items: flex-start; flex-direction: column;">
            <div style="margin-bottom: ${authRole === 'admin' ? '5px' : '0'};"><i data-lucide="dollar-sign" style="width: 14px; display: inline-block;"></i> <strong style="color: #fff;">${authRole === 'admin' ? 'Precio Reseller: ' : ''}${priceText}</strong></div>
            ${adminPricesHtml}
          </div>
        </div>
        
        <div class="product-card-actions">
          <button type="button" class="btn-action-details" data-id="${escapeHtml(p.serviceid)}">
            <i data-lucide="info"></i> Detalles
          </button>
          <button type="button" class="btn-action-buy" data-id="${escapeHtml(p.serviceid)}">
            <i data-lucide="shopping-cart"></i> Comprar
          </button>
        </div>
        <div class="product-card-extra hidden" id="extra_${escapeHtml(p.serviceid)}">
          <div class="extra-content">
            <p><strong>Descripción:</strong> ${p.rawItem.INFO ? escapeHtml(p.rawItem.INFO).replace(/\\n/g, '<br>') : 'Sin información adicional.'}</p>
            ${adminCustomPriceHtml}
          </div>
        </div>
      `;
      productsBody.appendChild(card);
    });

    lucide.createIcons();

    document.querySelectorAll('.btn-action-buy').forEach(btn => {
      btn.addEventListener('click', () => {
        const serviceId = btn.getAttribute('data-id');
        openPurchaseModal(serviceId);
      });
    });

    document.querySelectorAll('.btn-action-details').forEach(btn => {
      btn.addEventListener('click', () => {
        const serviceId = btn.getAttribute('data-id');
        const extraDiv = document.getElementById(`extra_${serviceId}`);
        if (extraDiv) {
          extraDiv.classList.toggle('hidden');
          const isHidden = extraDiv.classList.contains('hidden');
          btn.innerHTML = isHidden ? '<i data-lucide="info"></i> Detalles' : '<i data-lucide="chevron-up"></i> Ocultar';
          lucide.createIcons();
        }
      });
    });

    // Custom Price Form Listeners (Admin only)
    if (authRole === 'admin') {
      document.querySelectorAll('.custom-price-form').forEach(form => {
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const serviceId = form.getAttribute('data-id');
          const resellerPrice = form.querySelector('.custom-reseller-input').value;
          const clientPrice = form.querySelector('.custom-client-input').value;
          
          try {
            const res = await fetch('/api/admin/product-price', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
              body: JSON.stringify({ serviceId, resellerPrice, clientPrice })
            });
            if (res.ok) {
              alert('Precio manual guardado correctamente.');
              await syncProducts(true);
            } else {
              const errText = await res.text();
              alert(`Error al guardar el precio manual. Código: ${res.status}. Detalles: ${errText}`);
            }
          } catch (err) {
            alert('Error de conexión.');
          }
        });
      });

      document.querySelectorAll('.btn-reset-price').forEach(btn => {
        btn.addEventListener('click', async () => {
          const serviceId = btn.getAttribute('data-id');
          if (!confirm('¿Estás seguro de restablecer el precio para usar el cálculo automático global?')) return;
          try {
            const res = await fetch(`/api/admin/product-price/${serviceId}`, {
              method: 'DELETE',
              headers: { 'Authorization': `Bearer ${authToken}` }
            });
            if (res.ok) {
              alert('Precio restablecido a automático.');
              await syncProducts(true);
            } else {
              alert('Error al restablecer.');
            }
          } catch (err) {
            alert('Error de conexión.');
          }
        });
      });
    }
  }

  // Format price helper
  function formatPrice(credits) {
    const rawVal = parseFloat(credits) || 0;
    if (globalApiCurrency.toUpperCase() === 'MXN') {
      return `$${rawVal.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MXN`;
    }
    const mxnVal = rawVal * exchangeRate;
    return `$${mxnVal.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} MXN`;
  }

  // Smart Parser for Credentials
  function parseCredentials(text) {
    if (!text) return { user: 'N/A', pass: 'N/A' };
    let cleanText = String(text).replace(/<br\s*\/?>/gi, ' ').trim();
    
    // Pattern 1: user : xxx pass: yyy (Explicit labels)
    // Example: "Login Ditales ======== user : 803@tool pass: e91p1z6x"
    let match = cleanText.match(/(?:user|username|usuario|login)\s*[:=-]\s*(\S+)\s+(?:pass|password|contraseña|clave)\s*[:=-]\s*(\S+)/i);
    if (match) return { user: match[1], pass: match[2] };

    // Pattern 2: Two strings separated by space where the first might contain @ or letters/numbers, and the second is alphanumeric
    // Example: "UserX0041 3Wrd9dx35q" or "865@tool ei0058x6"
    // We clean up any prefixed text like "SUCCESS" or "Login Details"
    let tokens = cleanText.split(/\s+/).filter(t => t.length > 2 && !t.toLowerCase().includes('login') && !t.toLowerCase().includes('detail') && !/^[=]+$/.test(t));
    if (tokens.length >= 2) {
      // Pick the last two valid looking tokens if there's fluff before it
      return { user: tokens[tokens.length - 2], pass: tokens[tokens.length - 1] };
    }

    // Fallback if we couldn't parse cleanly
    return { user: 'VER_HISTORIAL', pass: 'VER_HISTORIAL' };
  }

  // Bulk save prices logic
  btnBulkSavePrices.addEventListener('click', async () => {
    if (authRole !== 'admin') return;
    
    // Collect all custom price inputs that might have been modified
    // We'll just collect ALL visible inputs for simplicity, 
    // or ideally only those that differ from original, but sending all is fine for small catalogs.
    // To be efficient, let's grab all inputs with class 'admin-price-input'
    const inputs = document.querySelectorAll('.admin-price-input');
    const bulkData = {};
    
    inputs.forEach(input => {
      const serviceId = input.getAttribute('data-id');
      const type = input.getAttribute('data-type'); // 'reseller' or 'client'
      const val = input.value;
      
      if (!bulkData[serviceId]) {
        bulkData[serviceId] = {};
      }
      if (type === 'reseller') bulkData[serviceId].resellerPrice = val;
      if (type === 'client') bulkData[serviceId].clientPrice = val;
    });

    const bulkArray = [];
    for (const serviceId in bulkData) {
      if (bulkData[serviceId].resellerPrice !== undefined && bulkData[serviceId].clientPrice !== undefined) {
        bulkArray.push({
          serviceId: serviceId,
          resellerPrice: bulkData[serviceId].resellerPrice,
          clientPrice: bulkData[serviceId].clientPrice
        });
      }
    }

    if (bulkArray.length === 0) {
      alert('No hay precios que guardar.');
      return;
    }

    const originalText = btnBulkSavePrices.innerHTML;
    btnBulkSavePrices.innerHTML = '<i data-lucide="loader"></i> Guardando...';
    lucide.createIcons();
    btnBulkSavePrices.disabled = true;

    try {
      const res = await fetch('/api/admin/product-price', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
        body: JSON.stringify({ bulk: bulkArray })
      });
      if (res.ok) {
        alert('Todos los precios manuales fueron guardados exitosamente.');
        await syncProducts(true);
      } else {
        alert('Error al guardar masivamente.');
      }
    } catch (err) {
      alert('Error de conexión.');
    } finally {
      btnBulkSavePrices.innerHTML = originalText;
      lucide.createIcons();
      btnBulkSavePrices.disabled = false;
    }
  });

  // Status indicator helper
  function updateStatus(type, text) {
    const dot = connectionStatus.querySelector('.status-dot');
    const label = connectionStatus.querySelector('.status-text');
    dot.className = 'status-dot ' + type;
    label.textContent = text;
  }

  // Loading state helper
  function setLoadingState(isLoading) {
    if (isLoading) {
      feedbackArea.innerHTML = `
        <div class="spinner-container">
          <div class="spinner"></div>
          <p>Consultando catálogo a la API de Dhru Fusion...</p>
        </div>
      `;
      feedbackArea.classList.remove('hidden');
      productsBody.parentElement.classList.add('hidden');
    }
  }

  // Error messaging helper
  function showError(message) {
    feedbackArea.innerHTML = `
      <div class="empty-state" style="color: var(--status-offline)">
        <i data-lucide="alert-triangle"></i>
        <h3>Error al Sincronizar</h3>
        <p style="color: var(--text-secondary)">${escapeHtml(message)}</p>
        <div class="error-details">
          Sugerencia: Asegúrate de que el endpoint sea correcto, que tu IP no esté bloqueada/no requiera lista blanca (whitelist) en el panel de Dhru Fusion, y que las credenciales ingresadas sean correctas. 
          <br><br>
          <button type="button" class="btn btn-secondary btn-small" style="margin: 0 auto; display: block;" id="btnErrorGoBack">
            Volver a Credenciales
          </button>
        </div>
      </div>
    `;
    feedbackArea.classList.remove('hidden');
    productsBody.parentElement.classList.add('hidden');
    lucide.createIcons();

    document.getElementById('btnErrorGoBack').addEventListener('click', () => {
      btnLogout.click();
    });
  }

  // HTML sanitization helper
  function escapeHtml(unsafe) {
    return String(unsafe)
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
  }

  // ============================================
  // ORDER HISTORY RENDERING LOGIC (RESELLER PANEL STYLE TABLE)
  // ============================================

  function renderOrderHistory() {
    historyBody.innerHTML = '';
    
    // Helper to colorize server responses
    function colorizeServerResponse(text) {
      if (!text) return 'Sin comentarios';
      let safeText = escapeHtml(String(text).replace(/<br\s*\/?>/gi, '\n'));
      // Match Key: Value pattern and wrap in spans for coloring
      safeText = safeText.replace(/^([a-zA-Z0-9_ \-\.]+):\s*(.*)$/gm, '<span style="color: var(--secondary-color); font-weight: 600;">$1:</span> <span style="color: #10b981;">$2</span>');
      return safeText;
    }
    
    const limit = parseInt(historyLimitFilter.value) || 10;
    const query = historySearchInput.value.toLowerCase().trim();

    let filteredHistory = [...orderHistory];

    if (query) {
      filteredHistory = filteredHistory.filter(item => {
        return item.serviceId.toString().toLowerCase().includes(query) ||
               item.serviceName.toLowerCase().includes(query) ||
               item.imei.toLowerCase().includes(query);
      });
    }

    historyCount.textContent = filteredHistory.length;

    const sortedHistory = [...filteredHistory];
    const pagedHistory = sortedHistory.slice(0, limit);

    if (pagedHistory.length === 0) {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">
          No hay órdenes registradas que coincidan con la búsqueda.
        </td>
      `;
      historyBody.appendChild(tr);
      return;
    }

    pagedHistory.forEach((item) => {
      const trHeader = document.createElement('tr');
      trHeader.className = 'history-row-header-click';
      trHeader.setAttribute('data-target-id', `details_row_${item.id}`);

      // Determine category (IMEI, SERVER, REMOTE)
      let category = item.serviceType;
      if (!category) {
        const matchingProduct = productsList.find(p => String(p.serviceid) === String(item.serviceId));
        if (matchingProduct && matchingProduct.serviceType === 'SERVER') {
          category = 'SERVER';
        } else {
          category = 'IMEI';
        }
      }

      let categoryClass = 'badge-category-imei';
      if (category === 'SERVER') {
        categoryClass = 'badge-category-server';
      } else if (category === 'REMOTE') {
        categoryClass = 'badge-category-remote';
      }

      // Determine status label and class
      let statusLabel = 'EN ESPERA';
      let statusClass = 'status-badge pending';
      if (item.status === 'success') {
        statusLabel = 'EXITOSO';
        statusClass = 'status-badge success';
      } else if (item.status === 'failed') {
        statusLabel = 'RECHAZADO';
        statusClass = 'status-badge rejected';
      }

      const formattedCost = formatPrice(item.costInCredits);
      
      let displayImeiNum = item.imei;
      if (displayImeiNum.startsWith('N/A (')) {
        // Parse "N/A (PlayerID: 12345)" into a nice UI
        const customData = displayImeiNum.replace('N/A (', '').slice(0, -1);
        const parts = customData.split(':');
        const key = parts[0];
        const val = parts.slice(1).join(':').trim();
        displayImeiNum = `
          <div style="display: flex; flex-direction: column; line-height: 1.4;">
            <span style="color: var(--text-secondary); font-size: 0.75rem;">${escapeHtml(key)}</span>
            <span style="display: flex; align-items: center; gap: 4px; font-family: 'Inter', sans-serif; font-size: 0.85rem; color: var(--text-primary);">
              <i data-lucide="info" style="width: 12px; height: 12px; color: #3b82f6;"></i>
              ${escapeHtml(val)}
            </span>
          </div>
        `;
      } else if (displayImeiNum === 'N/A') {
        displayImeiNum = `<span style="color: var(--text-muted); font-size: 0.8rem;">N/A</span>`;
      } else {
        // Normal IMEI, just show the number part and strip any appended custom fields for the summary column
        const imeiOnly = displayImeiNum.split(' ')[0];
        displayImeiNum = `<span style="font-family: 'Fira Code', monospace; color: #a5b4fc;">${escapeHtml(imeiOnly)}</span>`;
      }

      // Display CODE result matching screenshot under CODIGO column
      const displayCodeContent = String(item.statusText || '').replace(/<br\s*\/?>/gi, ' ');

      trHeader.innerHTML = `
        <td>
          <button type="button" class="btn-expand-row">+</button>
          <span class="product-id" title="ID de Orden" style="font-weight: bold; color: ${item.orderId ? 'var(--text-primary)' : 'var(--text-muted)'};">
            ${item.orderId ? escapeHtml(item.orderId) : '[Sin ID]'}
          </span>
        </td>
        <td>
          <strong>${escapeHtml(item.serviceName || item.service || 'Servicio')}</strong> 
          <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 2px;">ID: ${escapeHtml(item.serviceId || 'N/A')}</div>
        </td>
        ${authRole === 'admin' ? `
        <td>
          <div style="font-size: 0.85rem; color: #a78bfa; font-weight: 600;">${escapeHtml(item.username || 'N/A')}</div>
        </td>
        ` : ''}
        <td><span class="status-badge ${categoryClass}">${category}</span></td>
        <td>${displayImeiNum}</td>
        <td><span class="${statusClass}">${statusLabel}</span></td>
        <td><div style="font-family: 'Fira Code', monospace; font-size:0.8rem; color:#94a3b8; max-width:280px; display:inline-block; white-space:pre-wrap; word-break:break-word; background: rgba(0,0,0,0.4); padding: 0.3rem 0.6rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">${escapeHtml(displayCodeContent)}</div></td>
        <td><strong class="order-cost-val" style="color: #34d399;">$${parseFloat(item.costCharged || item.costInCredits || 0).toFixed(2)}</strong></td>
        ${authRole === 'admin' ? `
        <td>
          <strong style="color: #10b981;">+$${parseFloat(item.profit || 0).toFixed(2)}</strong>
        </td>
        ` : ''}
      `;

      // Expandable details sub-row
      const trDetails = document.createElement('tr');
      trDetails.className = 'history-detail-row hidden';
      trDetails.id = `details_row_${item.id}`;
      trDetails.innerHTML = `
        <td colspan="7" class="history-detail-cell">
          <div class="order-card-details" style="max-height: 500px; padding: 1rem 0;">
            <div class="details-grid">
              <div class="details-col">
                <span class="detail-label">PEDIDO DESDE</span>
                <strong class="detail-val">API</strong>
              </div>
              <div class="details-col">
                <span class="detail-label">DIRECCIÓN IP</span>
                <strong class="detail-val">${escapeHtml(item.ip || '127.0.0.1')}</strong>
              </div>
              <div class="details-col">
                <span class="detail-label">FECHA DE CREACIÓN</span>
                <strong class="detail-val">${escapeHtml(item.timestamp)}</strong>
              </div>
              <div class="details-col">
                <span class="detail-label">FECHA DE ACTUALIZACIÓN</span>
                <strong class="detail-val">${escapeHtml(item.updateTimestamp || item.timestamp)}</strong>
              </div>
            </div>
            <div class="details-comments">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                <span class="detail-label" style="margin-bottom: 0;">COMENTARIOS / CREDENCIALES ENTREGADAS</span>
                <div style="display: flex; gap: 0.5rem;">
                  <button type="button" class="btn btn-sm btn-copy-raw" style="background: rgba(255,255,255,0.1); color: #fff; border: 1px solid rgba(255,255,255,0.2); padding: 0.3rem 0.6rem; border-radius: 4px; font-size: 0.75rem; cursor: pointer; display: flex; align-items: center; gap: 0.3rem; font-weight: bold;"><i data-lucide="copy" style="width: 14px; height: 14px;"></i> Copiar</button>
                  ${item.status === 'success' ? `<button type="button" class="btn btn-sm btn-ticket" style="background: rgba(0,240,255,0.1); color: #00f0ff; border: 1px solid rgba(0,240,255,0.3); padding: 0.3rem 0.6rem; border-radius: 4px; font-size: 0.75rem; cursor: pointer; display: flex; align-items: center; gap: 0.3rem; font-weight: bold;"><i data-lucide="image" style="width: 14px; height: 14px;"></i> Generar Ticket</button>` : ''}
                </div>
              </div>
              <pre class="detail-val-pre">${colorizeServerResponse(item.statusText)}</pre>
            </div>
          </div>
        </td>
      `;

      // Hook click event
      trHeader.addEventListener('click', (e) => {
        // Expand row on click anywhere
        
        const detailsRow = document.getElementById(`details_row_${item.id}`);
        const btnExpand = trHeader.querySelector('.btn-expand-row');
        
        const isHidden = detailsRow.classList.contains('hidden');
        if (isHidden) {
          detailsRow.classList.remove('hidden');
          btnExpand.textContent = '-';
          btnExpand.style.background = 'var(--status-offline)';
          btnExpand.style.color = '#fff';
          btnExpand.style.borderColor = 'var(--status-offline)';
        } else {
          detailsRow.classList.add('hidden');
          btnExpand.textContent = '+';
          btnExpand.style.background = 'rgba(34, 211, 238, 0.1)';
          btnExpand.style.color = '#22d3ee';
          btnExpand.style.borderColor = 'rgba(34, 211, 238, 0.3)';
        }
      });

      historyBody.appendChild(trHeader);
      historyBody.appendChild(trDetails);

      // Ticket Button Event Listener
      if (item.status === 'success') {
        const btnTicket = trDetails.querySelector('.btn-ticket');
        if (btnTicket) {
          btnTicket.addEventListener('click', () => {
            currentTicketData = item;
            ticketClientPrice.value = '';
            ticketModal.classList.remove('hidden');
          });
        }
      }

      // Copy Button Event Listener
      const btnCopyRaw = trDetails.querySelector('.btn-copy-raw');
      if (btnCopyRaw) {
        btnCopyRaw.addEventListener('click', async () => {
          try {
            const rawText = String(item.statusText || '').replace(/<br\s*\/?>/gi, '\n').trim();
            await navigator.clipboard.writeText(rawText);
            
            const originalHtml = btnCopyRaw.innerHTML;
            btnCopyRaw.innerHTML = '<i data-lucide="check" style="width: 14px; height: 14px; color: #10b981;"></i> <span style="color: #10b981;">¡Copiado!</span>';
            lucide.createIcons();
            
            setTimeout(() => {
              btnCopyRaw.innerHTML = originalHtml;
              lucide.createIcons();
            }, 2000);
          } catch (e) {
            console.error('Error al copiar', e);
            alert('Error al copiar al portapapeles');
          }
        });
      }
    });
  }

  function addOrderToHistory(orderRecord) {
    orderRecord.localUniqueId = 'row_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    orderHistory.push(orderRecord);
    if (orderHistory.length > 100) {
      orderHistory.shift();
    }
    localStorage.setItem('dhru_order_history', JSON.stringify(orderHistory));
    renderOrderHistory();
  }

  // Hook history limit and search filter listeners
  historyLimitFilter.addEventListener('change', renderOrderHistory);
  historySearchInput.addEventListener('input', renderOrderHistory);

  // ============================================
  // DEBUG API CALLS LOGGING LOGIC
  // ============================================

  function maskApiKey(obj) {
    if (!obj || typeof obj !== 'object') return obj;
    const cloned = JSON.parse(JSON.stringify(obj));
    if (cloned.apiaccesskey) {
      cloned.apiaccesskey = '••••••••••••••••' + cloned.apiaccesskey.slice(-4);
    }
    return cloned;
  }

  function logApiCall(action, requestParams, responseData, isSuccess) {
    const timestamp = new Date().toLocaleTimeString('es-MX');
    const logId = 'log_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    const maskedParams = maskApiKey(requestParams);
    
    const entry = {
      id: logId,
      time: timestamp,
      action: action,
      params: maskedParams,
      response: responseData,
      isSuccess: isSuccess
    };

    consoleLogList.push(entry);
    if (consoleLogList.length > 40) {
      consoleLogList.shift();
    }

    renderConsoleLogs();
  }

  function renderConsoleLogs() {
    consoleCount.textContent = consoleLogList.length;
    if (consoleLogList.length === 0) {
      consoleEmpty.classList.remove('hidden');
      consoleList.innerHTML = '';
      return;
    }

    consoleEmpty.classList.add('hidden');
    consoleList.innerHTML = '';

    const reversedLogs = [...consoleLogList].reverse();

    reversedLogs.forEach(log => {
      const item = document.createElement('div');
      item.className = 'console-log-item';
      const statusText = log.isSuccess ? 'CONEXIÓN EXITOSA' : 'ERROR / RECHAZADO';
      const statusClass = log.isSuccess ? 'log-status-success' : 'log-status-failed';
      
      item.innerHTML = `
        <div class="console-log-header">
          <div>
            <span class="log-time">[${log.time}]</span>
            <span class="log-action">${escapeHtml(log.action.toUpperCase())}</span>
          </div>
          <strong class="${statusClass}">${statusText}</strong>
        </div>
        <div class="console-log-details" id="details_${log.id}">
          <div class="log-subheading">1. PARÁMETROS DE PETICIÓN ENVIADOS (CENSURADO):</div>
          <span>${escapeHtml(JSON.stringify(log.params, null, 2))}</span>
          <br><br>
          <div class="log-subheading">2. RESPUESTA COMPLETA DE LA API (JSON RAW):</div>
          <span>${escapeHtml(JSON.stringify(log.response, null, 2))}</span>
        </div>
      `;
      
      item.addEventListener('click', () => {
        const details = item.querySelector('.console-log-details');
        details.classList.toggle('show');
      });

      consoleList.appendChild(item);
    });
  }

  // ============================================
  // ORDER / PURCHASE MODAL LOGIC
  // ============================================

  function openPurchaseModal(serviceId) {
    const product = productsList.find(p => p.serviceid.toString() === serviceId.toString());
    if (!product) return;

    selectedProductForOrder = product;

    modalServiceId.textContent = `ID: ${product.serviceid}`;
    modalServiceName.textContent = product.service;
    modalServiceGroup.textContent = product.group;
    modalServicePrice.textContent = `Costo: ${formatPrice(product.credit)}`;

    // Balance check
    const cost = parseFloat(product.credit) || 0;
    const balance = globalApiCreditRaw || 0;
    
    if (balance >= cost) {
      modalBalanceWarning.style.display = 'block';
      modalBalanceWarning.style.color = '#34d399';
      modalBalanceWarning.style.background = 'rgba(16,185,129,0.1)';
      modalBalanceWarning.textContent = '✅ Saldo suficiente';
      btnConfirmOrder.removeAttribute('disabled');
    } else {
      modalBalanceWarning.style.display = 'block';
      modalBalanceWarning.style.color = '#f87171';
      modalBalanceWarning.style.background = 'rgba(239,68,68,0.1)';
      modalBalanceWarning.textContent = '❌ Saldo insuficiente comuníquese con el administrador #angel';
      btnConfirmOrder.removeAttribute('disabled');
    }
    
    // Service Info
    if (product.rawItem && (product.rawItem.INFO || product.rawItem.TIME || product.rawItem.FAQ)) {
      modalServiceInfoBlock.style.display = 'block';
      modalServiceTime.textContent = product.rawItem.TIME ? `Tiempo Estimado: ${product.rawItem.TIME}` : '';
      
      let infoHtml = product.rawItem.INFO || '';
      if (product.rawItem.FAQ) {
        infoHtml += `\n\nFAQ:\n${product.rawItem.FAQ}`;
      }
      modalServiceInfoText.innerHTML = infoHtml.replace(/<br\s*\/?>/gi, '\n').trim();
    } else {
      modalServiceInfoBlock.style.display = 'none';
    }

    imeiInput.value = '';
    customFieldsContainer.innerHTML = '';
    
    // Default: Assume IMEI is required unless explicitly disabled or if it's a known non-IMEI group
    let needsImei = true;
    const raw = product.rawItem;
    const gName = (product.group || '').toLowerCase();
    const sName = (product.service || '').toLowerCase();
    
    // Check various casing for Requires.Imei
    if (raw && (raw.requires_imei === false || raw.requires_imei === '0' || raw['Requires.Imei'] === false || raw['Requires.Imei'] === '0' || raw['Requires.IMEI'] === '0')) {
      needsImei = false;
    } else if (gName.includes('server') || gName.includes('file') || gName.includes('software') || gName.includes('streaming') || gName.includes('licencia') || gName.includes('credit')) {
      needsImei = false;
    } else if (sName.includes('chatgpt') || sName.includes('netflix') || sName.includes('spotify') || sName.includes('magis') || sName.includes('cuenta')) {
      needsImei = false;
    }
    
    // Store needsImei in a data attribute so we can use it during submit.
    // We will update this further down if we detect account-related custom fields.

    const requiresCustom = raw && (raw['Requires.Custom'] || raw.requires_custom || raw['REQUIRES.CUSTOM']);
    
    if (requiresCustom && Array.isArray(requiresCustom) && requiresCustom.length > 0) {
      requiresCustom.forEach(field => {
        const fieldNameRaw = field.fieldname || field.description || '';
        const fName = fieldNameRaw.toLowerCase();
        
        // If it asks for an email, user, or password, it's an account service, not a phone unlock
        if (fName.includes('email') || fName.includes('correo') || fName.includes('usuario') || fName.includes('password') || fName.includes('contraseña')) {
          needsImei = false;
        }
        
        const inputGroup = document.createElement('div');
        inputGroup.className = 'input-group';
        
        const label = document.createElement('label');
        label.textContent = `${fieldNameRaw || 'Campo adicional'}${field.required ? ' *' : ''}`;
        
        const wrapper = document.createElement('div');
        wrapper.className = 'input-wrapper';
        
        const icon = document.createElement('i');
        icon.setAttribute('data-lucide', 'plus-circle');
        
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'custom-field-input';
        input.setAttribute('data-fieldname', field.fieldname || 'custom');
        input.placeholder = field.description || '';
        if (field.required) input.required = true;

        wrapper.appendChild(icon);
        wrapper.appendChild(input);
        inputGroup.appendChild(label);
        inputGroup.appendChild(wrapper);
        
        customFieldsContainer.appendChild(inputGroup);
      });
    }

    // Now that we've checked custom fields, finally set the UI visibility
    // If the API explicitly says requires_imei is 0, we can just hide the whole block.
    // Otherwise, we leave the block visible but check the auto-generate box based on our intelligence.
    
    if (raw && (raw.requires_imei === false || raw.requires_imei === '0' || raw['Requires.Imei'] === false || raw['Requires.Imei'] === '0' || raw['Requires.IMEI'] === '0')) {
      imeiInputGroup.classList.add('hidden');
      imeiInput.required = false;
      imeiAutoGenerate.checked = true; // ensure backend ignores it
    } else {
      imeiInputGroup.classList.remove('hidden');
      
      // Ensure the auto-generate box is always unchecked by default, per user request
      imeiAutoGenerate.checked = false;
      
      // Manually trigger the change event to update UI
      imeiAutoGenerate.dispatchEvent(new Event('change'));
    }

    purchaseModal.classList.remove('hidden');
    lucide.createIcons();
  }

  function closePurchaseModal() {
    purchaseModal.classList.add('hidden');
    selectedProductForOrder = null;
  }

  btnCloseModal.addEventListener('click', closePurchaseModal);
  btnCancelOrder.addEventListener('click', closePurchaseModal);

  purchaseModal.addEventListener('click', (e) => {
    if (e.target === purchaseModal) {
      closePurchaseModal();
    }
  });

  orderForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!selectedProductForOrder) return;

    const username = localStorage.getItem('dhru_username');
    const serviceid = selectedProductForOrder.serviceid;
    const serviceName = selectedProductForOrder.service;
    const serviceType = selectedProductForOrder.serviceType || 'IMEI'; // Extract service type
    const costInCredits = selectedProductForOrder.credit;
    const timestamp = new Date().toLocaleString('es-MX');

    // The user either typed an IMEI or checked the box to auto-generate
    const needsImei = !imeiAutoGenerate.checked;
    let imei = '';
    let imeiDataString = '';
    
    // If the whole group is hidden (meaning requires_imei was explicitly 0), or if the box is checked
    if (needsImei && !imeiInputGroup.classList.contains('hidden')) {
      imei = imeiInput.value.trim();
      if (imei.length !== 15) {
        alert('El IMEI debe tener exactamente 15 dígitos numéricos.');
        return;
      }
      imeiDataString = imei;
    } else {
      // Generate a unique 15-digit dummy IMEI: Date.now() (13 digits) + 2 random digits
      const randomSuffix = Math.floor(Math.random() * 90 + 10).toString();
      imei = Date.now().toString() + randomSuffix;
      imeiDataString = 'N/A';
    }

    if (!authToken) {
      alert('Faltan sesión del portal. Inicia sesión nuevamente.');
      return;
    }

    const custom_fields = {};
    document.querySelectorAll('.custom-field-input').forEach(input => {
      const name = input.getAttribute('data-fieldname');
      if (name) {
        custom_fields[name] = input.value.trim();
      }
    });

    const btnConfirm = document.getElementById('btnConfirmOrder');
    const originalText = btnConfirm.querySelector('span').textContent;
    btnConfirm.setAttribute('disabled', 'true');
    btnConfirm.querySelector('span').textContent = 'Procesando...';

    const customKeys = Object.keys(custom_fields);
    if (customKeys.length > 0) {
      imeiDataString += ' (';
      customKeys.forEach((key, index) => {
        imeiDataString += `${key}: ${custom_fields[key]}${index < customKeys.length - 1 ? ', ' : ''}`;
      });
      imeiDataString += ')';
    }

    const orderPayload = {
      serviceid,
      imei,
      custom_fields,
      serviceType,
      serviceName
    };

    try {
      const response = await fetch('/api/order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(orderPayload)
      });

      let data = await response.json();

      if (!response.ok) {
        if (data.error === 'ADMIN_INSUFFICIENT_BALANCE') {
          if (confirm('No tienes saldo disponible en tu Bolsa personal de Ganancias Admin para esta compra.\n\n¿Deseas descontarlo de todos modos y usar fondos globales?')) {
            orderPayload.bypassAdminBalance = true;
            // Retry fetch
            const retryResponse = await fetch('/api/order', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
              },
              body: JSON.stringify(orderPayload)
            });
            const retryData = await retryResponse.json();
            if (!retryResponse.ok) {
              throw new Error(retryData.error || 'Error al conectar con el servidor en reintento.');
            }
            data = retryData; // Update data with success response
          } else {
            return; // User cancelled
          }
        } else {
          logApiCall('placeimeiorder', orderPayload, data, false);
          throw new Error(data.error || 'Error al conectar con el servidor.');
        }
      }

      if (data.ERROR) {
        logApiCall('placeorder', orderPayload, data, false);
        let errMsg = 'Error desconocido de Dhru';
        if (Array.isArray(data.ERROR) && data.ERROR.length > 0) {
          errMsg = typeof data.ERROR[0] === 'object' ? (data.ERROR[0].MESSAGE || JSON.stringify(data.ERROR[0])) : data.ERROR[0];
        } else if (typeof data.ERROR === 'object') {
          errMsg = data.ERROR.MESSAGE || data.ERROR.message || JSON.stringify(data.ERROR);
        } else if (typeof data.ERROR === 'string') {
          errMsg = data.ERROR;
        }
        throw new Error(`Dhru Error: ${errMsg}`);
      }

      logApiCall('placeimeiorder', orderPayload, data, true);

      let orderId = '';
      let msg = '';
      
      if (data.SUCCESS && Array.isArray(data.SUCCESS) && data.SUCCESS.length > 0) {
        const successItem = data.SUCCESS[0];
        orderId = successItem.REFERENCEID || successItem.referenceid || successItem.ORDERID || successItem.orderid || successItem.ID || successItem.id || '';
        msg = successItem.MESSAGE || successItem.message || 'Exitoso';
      } else if ((data.SUCCESS === true || data.SUCCESS === 'true') && data.RESULT) {
        const resObj = data.RESULT;
        orderId = resObj.REFERENCEID || resObj.referenceid || resObj.ORDERID || resObj.orderid || resObj.ID || resObj.id || '';
        msg = resObj.MESSAGE || resObj.message || 'Exitoso';
      } else {
        orderId = data.REFERENCEID || data.referenceid || data.ORDERID || data.orderid || data.ID || data.id || '';
        msg = data.MESSAGE || data.message || 'Exitoso';
      }

      // Add success log to history (Waiting state initially)
      addOrderToHistory({
        timestamp,
        updateTimestamp: new Date().toLocaleString('es-MX'),
        serviceId: serviceid,
        serviceName,
        imei: imeiDataString,
        costInCredits,
        orderId,
        status: 'pending', // Set to pending wait state so it gets checked on Sync!
        statusText: msg,
        ip: data.clientIp || '127.0.0.1',
        serviceType
      });

      alert(`¡Pedido Exitoso!\n\nID de Orden: ${orderId}\nMensaje: ${msg}`);
      closePurchaseModal();

      // Auto-trigger order status query after 1.5 seconds to pull codes instantly if completed
      setTimeout(() => {
        btnSyncHistory.click();
      }, 1500);

    } catch (err) {
      console.error(err);
      
      // Add error log to history
      addOrderToHistory({
        timestamp,
        updateTimestamp: new Date().toLocaleString('es-MX'),
        serviceId: serviceid,
        serviceName,
        imei: imeiDataString,
        costInCredits,
        orderId: 'Error',
        status: 'failed',
        statusText: err.message,
        ip: '127.0.0.1',
        serviceType
      });

      alert(`Error al realizar pedido:\n${err.message}`);
    } finally {
      btnConfirm.removeAttribute('disabled');
      btnConfirm.querySelector('span').textContent = originalText;
    }
  });

  // -------------------------------------------------------------
  // Ticket Generator Modal & Html2Canvas Logic
  // -------------------------------------------------------------
  
  const closeTicketModal = () => {
    ticketModal.classList.add('hidden');
    ticketClientPrice.value = '';
    currentTicketData = null;
    
    // Hide preview on close
    const ticketPreviewContainer = document.getElementById('ticketPreviewContainer');
    if (ticketPreviewContainer) {
      ticketPreviewContainer.classList.add('hidden');
    }
  };

  btnTicketClose.addEventListener('click', closeTicketModal);
  btnCancelTicket.addEventListener('click', closeTicketModal);

  btnGenerateTicketFinal.addEventListener('click', async () => {
    if (!currentTicketData) return;
    
    // Set UI State to loading
    const originalBtnHTML = btnGenerateTicketFinal.innerHTML;
    btnGenerateTicketFinal.innerHTML = '<i data-lucide="loader" class="lucide-spin"></i><span>Generando...</span>';
    lucide.createIcons();
    btnGenerateTicketFinal.setAttribute('disabled', 'true');

    try {
      // Populate Template
      const title = String(currentTicketData.serviceName || 'UNLOCK TOOL').split('[')[0].trim();
      ticketTitle.textContent = title;

      const orderIdNode = document.getElementById('ticketOrderId');
      if (orderIdNode) {
        orderIdNode.textContent = `ID: #${currentTicketData.orderId || 'N/A'}`;
      }

      const price = ticketClientPrice.value.trim();
      if (price && !isNaN(price)) {
        ticketPriceVal.textContent = parseFloat(price).toLocaleString('es-MX', { minimumFractionDigits: 2 });
        ticketPricePill.classList.remove('hidden');
      } else {
        ticketPricePill.classList.add('hidden');
      }

      // Format Type logic
      const formatType = ticketFormatType.value;
      let rawText = String(currentTicketData.statusText || '');
      
      // Brutal optimization: truncate extremely long texts to prevent html2canvas from crashing the browser's layout engine
      if (rawText.length > 800) {
        rawText = rawText.substring(0, 800) + '\n\n[...Texto truncado para optimización de imagen...]';
      }
      
      ticketRawTextVal.textContent = rawText.replace(/<br\s*\/?>/gi, '\n').trim();

      if (formatType === 'raw') {
        ticketParsedBox.classList.add('hidden');
        ticketRawBox.classList.remove('hidden');
      } else {
        ticketParsedBox.classList.remove('hidden');
        ticketRawBox.classList.add('hidden'); // Brutal optimization: DO NOT render the raw text block if we only want parsed info!
        
        // Parse Credentials
        const creds = parseCredentials(currentTicketData.statusText);
        ticketUserVal.textContent = creds.user;
        ticketPassVal.textContent = creds.pass;
      }

      // Bring template to view momentarily
      ticketTemplateContainer.style.opacity = '1';

      // Copy to Clipboard (Modern approach with Promise to preserve user gesture)
      try {
        const makeImagePromise = async () => {
          // Brutal optimization: Using html-to-image (modern) instead of html2canvas or dom-to-image.
          // This avoids Firefox layout freezes, respects web fonts, and renders instantly using SVG foreignObject.
          const blob = await htmlToImage.toBlob(ticketTemplate, {
            backgroundColor: '#111116',
            pixelRatio: 2, // Retina quality: text and logos will be ultra-crisp!
            style: {
              transform: 'scale(1)',
              transformOrigin: 'top left'
            }
          });
          
          ticketTemplateContainer.style.opacity = '0';
          
          // Show Preview immediately
          const ticketPreviewContainer = document.getElementById('ticketPreviewContainer');
          const ticketPreviewImg = document.getElementById('ticketPreviewImg');
          if (ticketPreviewContainer && ticketPreviewImg) {
            ticketPreviewImg.src = URL.createObjectURL(blob);
            ticketPreviewContainer.classList.remove('hidden');
          }
          
          return blob;
        };
        
        // This tells the browser: "We are putting a promise in the clipboard right now due to a user click"
        const clipboardItem = new ClipboardItem({ 'image/png': makeImagePromise() });
        await navigator.clipboard.write([clipboardItem]);
        
        btnGenerateTicketFinal.innerHTML = '<i data-lucide="check"></i><span>¡Copiado!</span>';
        lucide.createIcons();
        
        setTimeout(() => {
           btnGenerateTicketFinal.removeAttribute('disabled');
           btnGenerateTicketFinal.innerHTML = originalBtnHTML;
           lucide.createIcons();
        }, 3000);
        
      } catch (clipboardErr) {
        console.error('Clipboard copy failed:', clipboardErr);
        // Sometimes the clipboard error is just "NotAllowedError" or "Document is not focused"
        // Let's fallback to showing the preview and a smaller alert
        alert('Tu navegador requiere permiso manual. Haz clic derecho en la imagen de abajo y selecciona "Copiar imagen".');
        
        btnGenerateTicketFinal.removeAttribute('disabled');
        btnGenerateTicketFinal.innerHTML = originalBtnHTML;
        lucide.createIcons();
      }
    } catch (err) {
      console.error('Error rendering ticket:', err);
      alert('Hubo un error al generar la imagen. Revisa la consola.');
      btnGenerateTicketFinal.removeAttribute('disabled');
      btnGenerateTicketFinal.innerHTML = originalBtnHTML;
      lucide.createIcons();
    }
  });

  // --- ADMIN USERS MODAL LOGIC ---
  const adminUsersModal = document.getElementById('adminUsersModal');
  const btnCloseAdminModal = document.getElementById('btnCloseAdminModal');
  const btnCreateUserFormToggle = document.getElementById('btnCreateUserFormToggle');
  const createUserFormContainer = document.getElementById('createUserFormContainer');
  const createUserForm = document.getElementById('createUserForm');
  const btnCancelCreateUser = document.getElementById('btnCancelCreateUser');
  const usersTableBody = document.getElementById('usersTableBody');
  const adminProfitDisplay = document.getElementById('adminProfitDisplay');
  const adminSettingsForm = document.getElementById('adminSettingsForm');
  const inputResellerMarkup = document.getElementById('inputResellerMarkup');
  const inputClientMarkup = document.getElementById('inputClientMarkup');

  btnRechargeBalance.addEventListener('click', () => {
    alert('Para recargar saldo, por favor contacta al administrador Ángel (Admin).\n\nEl sistema no permite solicitar servicios que superen tu crédito actual.');
  });

  btnAdminManage.addEventListener('click', async () => {
    adminUsersModal.classList.remove('hidden');
    await loadAdminData();
  });

  btnCloseAdminModal.addEventListener('click', () => {
    adminUsersModal.classList.add('hidden');
  });

  btnCreateUserFormToggle.addEventListener('click', () => {
    createUserFormContainer.classList.toggle('hidden');
  });

  btnCancelCreateUser.addEventListener('click', () => {
    createUserFormContainer.classList.add('hidden');
    createUserForm.reset();
  });

  async function loadAdminData() {
    try {
      const statsRes = await fetch('/api/admin/stats', { headers: { 'Authorization': `Bearer ${authToken}` }});
      if (statsRes.ok) {
        const stats = await statsRes.json();
        adminProfitDisplay.textContent = `$${parseFloat(stats.profitBalance || 0).toFixed(2)}`;
      }

      const settingsRes = await fetch('/api/admin/settings', { headers: { 'Authorization': `Bearer ${authToken}` }});
      if (settingsRes.ok) {
        const set = await settingsRes.json();
        inputResellerMarkup.value = parseFloat(set.resellerMarkup || 0).toFixed(2);
        inputClientMarkup.value = parseFloat(set.clientMarkup || 0).toFixed(2);
      }

      const usersRes = await fetch('/api/users', { headers: { 'Authorization': `Bearer ${authToken}` }});
      if (usersRes.ok) {
        const users = await usersRes.json();
        usersTableBody.innerHTML = '';
        users.forEach(u => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${u.id}</td>
            <td><strong>${escapeHtml(u.username)}</strong></td>
            <td><span class="status-badge ${u.role === 'admin' ? 'badge-category-server' : 'badge-category-imei'}">${u.role.toUpperCase()}</span></td>
            <td><strong style="color: #34d399;">$${parseFloat(u.credits).toFixed(2)}</strong></td>
            <td style="text-align: right;">
              ${u.role !== 'admin' ? `
                <div style="display: flex; gap: 5px; justify-content: flex-end;">
                  <button type="button" class="btn btn-sm btn-recharge-user" data-id="${u.id}" style="background: rgba(34,211,238,0.1); color: #22d3ee;">Añadir Saldo</button>
                  <button type="button" class="btn btn-sm btn-deduct-user" data-id="${u.id}" style="background: rgba(244,63,94,0.1); color: #f43f5e;">Quitar Saldo</button>
                  <button type="button" class="btn btn-sm btn-delete-user" data-id="${u.id}" style="background: rgba(239,68,68,0.1); color: #ef4444;">Eliminar</button>
                </div>
              ` : '<span style="color:var(--text-muted); font-size:0.8rem;">Admin</span>'}
            </td>
          `;
          usersTableBody.appendChild(tr);
        });

        // Bind Actions
        document.querySelectorAll('.btn-delete-user').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const id = e.target.dataset.id;
            if (confirm('¿Eliminar este usuario?')) {
              await fetch(`/api/users/${id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${authToken}` }});
              loadAdminData();
            }
          });
        });

        document.querySelectorAll('.btn-recharge-user').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const id = e.target.dataset.id;
            const user = users.find(u => u.id == id);
            const addAmount = prompt(`¿Cuánto saldo añadir a ${user.username}? (Ingresa cantidad a sumar)`);
            if (addAmount && !isNaN(parseFloat(addAmount))) {
              const newCredits = parseFloat(user.credits) + Math.abs(parseFloat(addAmount));
              await fetch(`/api/users/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                body: JSON.stringify({ credits: newCredits })
              });
              loadAdminData();
            }
          });
        });

        document.querySelectorAll('.btn-deduct-user').forEach(btn => {
          btn.addEventListener('click', async (e) => {
            const id = e.target.dataset.id;
            const user = users.find(u => u.id == id);
            const subAmount = prompt(`¿Cuánto saldo QUITAR a ${user.username}? (Ingresa cantidad a restar)`);
            if (subAmount && !isNaN(parseFloat(subAmount))) {
              let newCredits = parseFloat(user.credits) - Math.abs(parseFloat(subAmount));
              if (newCredits < 0) newCredits = 0;
              await fetch(`/api/users/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
                body: JSON.stringify({ credits: newCredits })
              });
              loadAdminData();
            }
          });
        });
      }
    } catch (e) {
      console.error('Failed to load admin data', e);
    }
  }

  createUserForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;
    const credits = document.getElementById('newCredits').value;
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
        body: JSON.stringify({ username, password, credits })
      });
      if (res.ok) {
        createUserFormContainer.classList.add('hidden');
        createUserForm.reset();
        loadAdminData();
      } else {
        const err = await res.json();
        alert(err.error || 'Error al crear usuario');
      }
    } catch (e) {
      alert('Error de conexión');
    }
  });

  if (adminSettingsForm) {
    adminSettingsForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        const res = await fetch('/api/admin/settings', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
          },
          body: JSON.stringify({
            resellerMarkup: inputResellerMarkup.value,
            clientMarkup: inputClientMarkup.value
          })
        });
        if (res.ok) {
          alert('Configuración guardada correctamente. El catálogo se recargará ahora para reflejar los nuevos precios.');
          await syncProducts(true);
        } else {
          alert('Error al guardar configuración');
        }
      } catch (err) {
        alert('Error de conexión');
      }
    });
  }

});
